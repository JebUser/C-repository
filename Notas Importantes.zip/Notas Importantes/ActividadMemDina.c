#include <stdlib.h>
#include <stdio.h>
int *crearArreglo(void);
int *recibirEdades(int *arreglo);
void calcularProm(int *arreglo);
int *reducirArreglo(int *arreglo);
void recorrerArr(int *arreglo);
void recorrerArr2(int *arreglo);

int * crearArreglo(void){
    int *arreglo = calloc(20, sizeof(int));
    return arreglo;
}

int * recibirEdades(int *arreglo){
    int Edad = 0;
    int cont = 0;
    do{
        printf("Ingrese su edad: ");
        scanf("%d", &Edad);
        arreglo[cont] = Edad;
        cont++;
    }
    while(Edad >= 0 && cont < 10);  
    return arreglo;
}

void calcularProm(int *arreglo){
    float sumaEdad = 0;
    for(int i = 0; i < 20; i++){
        sumaEdad += arreglo[i];
    }
    sumaEdad /= 10;
    printf("El promedio de las edades es: %f", sumaEdad);
}

int * reducirArreglo(int *arreglo){
    int cont0 = 0;
    for(int i = 0; i < 20; i++){
        if(arreglo[i] != 0){ // tambien puede ser == 0
            cont0++;
        }
    }
    arreglo = (int*)realloc(arreglo,cont0* sizeof(int)); // si es == 0 poner 20-cont0
    return arreglo;
}

void recorrerArr(int *arreglo){
    for(int i = 0; i < 20; i++){
        printf("%d ", arreglo[i]);
    }
}
void recorrerArr2(int *arreglo){
    for(int i = 0; i < 10; i++){
        printf("%d ", arreglo[i]);
    }
}
int main(){
    int *f1 = crearArreglo();
    recorrerArr(f1);
    printf("\n");
    int *f2 = recibirEdades(f1);
    printf("\n");
    calcularProm(f2);
    printf("\n");
    reducirArreglo(f2);
    printf("\n");
    recorrerArr2(f2);
    return 0;
}

