/*
*P_semestre = 10, modifica el valor de la variable donde esta asignado el puntero
void update_int(int *value, int new_value);

int value = 10
update_int(&value, 25){
    *value = new_value;
}


punteros structs

teniendo un estruct "estudiante"
para poner un puntero se pone estudiante *p_e1
se inicializa
estudiante e1 = {...}
estudiante *p_e1 = %e1

acceso
(*p_e1).dato
p_e1->dato

void fun(estudiante *pe){
    printf("...");
    fgets(pe->dato,30,stdin)
    ...
}
estudiante *p_e1 = &e1;
p_e1 +=1 //desplaza el apuntador bloque a la derecha de la pos original (xbytes)
p_e1 -=1 //desplaza el apuntador bloque a la izquierda de la pos original (xbytes)
solo se puede sumar y restar
*/