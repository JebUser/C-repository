#include <stdio.h>

typedef struct nodoArbol{
    int valor;
    struct nodoArbol* pHijoDer;
    struct nodoArbol* pHijoIzq;
    struct nodoArbol* pHijoPadre;
}nodo_Arbol;

typedef enum{
    VACIO = 0,
    NO_VACIO = 1
}estado;

/*
1 --> si es una hoja
0 --> no es una hoja
-1 --> es NULL el arbol esta vacio
*/

estado esVacio(nodo_Arbol * raiz){
    if(raiz == NULL){
        return VACIO;
    }
    else{
        return NO_VACIO;
    }
}

int esHoja(nodo_Arbol *pRaiz){
    if(pRaiz != NULL){
        if(pRaiz->pHijoIzq == NULL && pRaiz->pHijoDer == NULL){
            return 1;
        }
        else{
            return 0;
        }
    }
    else{
        return -1;
    }
}

int main(){
    nodo_Arbol *pRaizArbol = NULL;

}