/*
Busquedas

int data[10] = {....};

int busqueda_lineal(int clave){
    for(int index = 0; index < 10; index++){
        if(data[index] == clave){
            return 1;
        }
    }
    return 0;
}

Hash(clave) = dirección
*/