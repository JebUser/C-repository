//Estructuras de control

/*Estructuras básicas de control
=======================================
Uso de el "If"
El uso de "else"

    if(condicion){
        instruccion 1;
    }
    else if{
        instruccion 2;
    }
    else{
        instruccion 3;
    }

Se pueden usar If dentro de If
=======================================
Operador ternario
condicional en una sola linea de codigo

    condicion ? intruccion1 : instruccion2

========================================
Los "switch"

 switch(selector){
    case etiqueta1:
        intrucciones;
        break;
    default:
        instrucciones;
 }
=========================================
Los bucles

"while"
    while(condicion){
        instrucciones;
    }

"for"
    for(init; cond_iter; incre){
        instrucciones;
    }

"do-while"
    do{
        instrucciones;
    }
    while(condiciones);
==========================================
Interrupciones

"continue": saltar una unica iteracion del bucle
"break": terminar todo el bucle
*/