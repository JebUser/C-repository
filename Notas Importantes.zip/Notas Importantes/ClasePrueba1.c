#include <stdio.h>
void main(){

    int x = 10;
    float y = 13.6;
    char letra = 'a';
    char cadena[15] = "Omasthus wine";
    printf("El valor es: %d\n", x);
    printf("El valor de x es: %d y el valor de Y es: %f\n", x, y);
    printf("El valor de la letra es: %c\n", letra);
    printf("La cadena es %s\n", cadena);
}
/*
%d para enteros
%f para float
%c para char
%!f para double
%i para entero
%s para string
*/


//Void es para procedimientos
//Int main es para función