/*
==============
Funciones
==============

Defines Tareas especifias y se utilizan normalmente printf() y scanf()

Declarar prototipos de funciones: Este ayuda al compilador a conocer
la estructura del valor de la función

Se declarar antes de la funcion principal

    int suma(int a, int b);
***************
tipo_retorno nombre_fun(parametros){
    cuerpo/intrucciones
    return
}

int suma(int a, int b){
    return a+b;
}
Scope de variables:
    Var. Local -----> dentro de funciomes
    Var. Global -----> fuera de las funciones
***************
*/