/*
Sirve para almacenar muchos datos de diferentes tipos
Estructura de dato: coleccion de un tipo especial de dato
    nombre del miemrbo
    nombre > char
    edad > int
    cedula > int

struct "nombre_structura"{
    mienbro_1;
    mienbro_2
};

struct Estudiante{
    char nombre;
    int cedula;
    int edad;
}


struct Estudiante estudiante_1;
estudiante_1.nombre = "A";
estudiante_1.edad = 20;
estudiante_1.cedula = 111112345;

struct Estdudiante estudiante_1 = {"A", 20, 111123343};
para acceder a una estructura se utiliza (.) estudiante_1.nombre;

typedef crear un sinonimo de dato primitivo

typdefef double Longitud
Longitud distancia = 47.4;

typedef struct Estudiante{
    miembro_1;
    miembro_2;
    ...
}Estudiante;

Estudiante estudiante_1

Arreglos estructuras
struct Estudiante estudiante[100] = {estudiante_1, estudiante_2,...}
Usando typedef
Estudiante estudiante[100] = {estudiante_1, estudiante_2,...}

struct Estructura_1{
    miembro_1;
    miembro_2;
}
struct Estructura_2{
    miembro_1;
    miembro_2;
    struct Estructura_1 estructura;
}
ENUMERADOR

enum nombre_enum{
    enum_1, //0
    enum_2, //1
    ...
    enum_n, //n-1
}
Declara constantes

enum Booleano {FALSE, TRUE};
*/
#include <stdio.h>
struct Productos
{
    char nombre;
    int precio;
    char description;
};

/*
deftype struct Productos
{
    char nombre;
    int precio;
    char description;
} Producto; el alias del producto
*/

int main(){
    struct Productos producto1 = {'A', 30, 'a'};
    struct Productos producto2 = {'B', 50, 'b'};
    struct Productos Productos[10] = {producto1, producto2};
    
    
    //poner lo mismo pero sin el struct //Productos producto1 = {'A', 30, 'a'};
    printf("Nombre del producto: %c\n", producto1.nombre);
    printf("Precio del producto: %d\n", producto1.precio);
    printf("Descripcion del producto: %c", producto1.description);
    
    return 0;
}