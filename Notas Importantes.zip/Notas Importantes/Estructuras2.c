/*
La memoria dinamica es la capacidad de asignar memoria en el tiempo de ejecucion
NULL = SE ACABO LA MEMORIA
    sizeof: tamaño de tipo de dato en bytes
    malloc (numBytes): reserva espacio de memoria predeterminado pero no inicializa los datos
    free(puntero): libera la memoria reservada, elimina la direccion de memoria
    Queda espacio libre, con variables que se pueden reescribir en el futuro
    requiere stdlib
*/
#include <stdio.h>
#include <stdlib.h>

void usoMalloc(){
    int *p;
    //Asigna el espacio de memoria que ocupa un entorno
    p = malloc(sizeof(int));
    if( p != NULL){
        *p = 5;
        printf("El valor de la variable es %d Y su dirección es %p", *p, p);
        free(p);
    }
}

/*
Inizializar
int *pArray = malloc(5 * sizeof(int)) ----> inizializar arreglo con direcciones

Realloc
arreglo = (int*)realloc(arreglo(apuntador),N* sizeof(int))

Calloc
int *arreglo = calloc(N, sizeof(int));
asignar espacios con datos
*/