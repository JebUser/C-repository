#include <stdio.h>
#include <unistd.h>

void imprimir_matriz();

void imprimir_matriz(){

    int matriz[4][4] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {10, 11, 12, 13}, {14, 15, 16, 17}};
        for(int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                printf("%d\t", matriz[i][j]); // \t para matrices
            }
            printf("\n");
        }
    return;
}

int main(){
    imprimir_matriz();
    return 0;
}

