#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
    int valor;
    struct nodo *pSgte;
}nodo;

typedef struct{
    nodo *cabezaPila;
}pila;

typedef enum{
    VACIA = 0,
    NO_VACIA = 1
}estado;

pila *crearPila(){
    pila *nuevaPila = malloc(sizeof(pila));
    nuevaPila->cabezaPila = NULL;
    return nuevaPila;
}

estado esVacia(pila *p){
    if(p->cabezaPila == NULL){
        return VACIA;
    }
    else{
        return NO_VACIA;
    }
}

void pushPila(pila *p, int valor){
    nodo *nuevoNodo = malloc(sizeof(nodo));
    if(nuevoNodo == NULL){
        printf("No se separo memoria");
        return;
    }
    else{
        nuevoNodo->valor = valor;
        if(esVacia(p) == VACIA){
            p->cabezaPila = nuevoNodo;
            nuevoNodo->pSgte = NULL;
        }
        else{
            nuevoNodo->pSgte = p->cabezaPila;
            p->cabezaPila = nuevoNodo;
            
        }
    }
}

int main(){

    return 0;
}