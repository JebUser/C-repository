#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
    int valor;
    struct nodo * pSgte;
} nodo_t;

nodo_t * insertarNodo(nodo_t * pCabeza, int valor){
    nodo_t * pNuevoNodo = (nodo_t *) malloc(sizeof(nodo_t));
    if(pNuevoNodo == NULL){
        printf("No fue posible reservar memoria para el nuevo nodo");
        return pCabeza;
    }
    else{
        pNuevoNodo -> valor = valor;
    }
    pNuevoNodo -> pSgte = pCabeza;
    pCabeza = pNuevoNodo;
    return pCabeza;
}

void imprimirLista(nodo_t * pCabeza){
	nodo_t * pAux = pCabeza;
	while(pAux != NULL){
		printf("-> %d <- \n", pAux -> valor);
		pAux = pAux -> pSgte;
	}
}

void main(){
    nodo_t * pCabeza = NULL;

    pCabeza = insertarNodo(pCabeza, 10);
    pCabeza = insertarNodo(pCabeza, 7);
    pCabeza = insertarNodo(pCabeza, 3);
    imprimirLista(pCabeza);
}