/*
Otros tipos de datos
#define: sentencia de preprocesamiento para definir una constante
=========================
###Arreglos###

Una secuencia de objetos del MISMO TIPO.
La secuencia de los arreglos es de caracter n-1 donde n es la posción de la lista
    en lenguaje natural(lenguaje normal)

    int(tipo) arreglo(variable)[Cantidad de valores] = {elementos};
    int arreglo[6] = {1, 2, 3, 4, 5 ,6};

    Para acceder a un elemento de un arreglo
    arreglo[2] ----> 3
============================
###Matrices###
Son arreglos multidimensionales
Estan organizadas en filas y columnas ordenadas

Se deben iniciar indicando las filas y las columnas ij
    int matriz[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    una matriz 3x3 donde F1: 1-3, F2: 4-5, F3: 7, 8, 9
    Para acceder a un elemento de una matriz debe indicarse la fila y la columna
    matriz[2][3] ------> 6
============================

*/