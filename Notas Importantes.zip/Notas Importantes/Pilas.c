#include<stdlib.h>
#include<stdio.h>

typedef struct nodo{
	int valor;
	struct nodo * pSgte;
}nodo_t;

typedef struct 
{
	nodo_t * cabezaPila;
}pila_t;

typedef enum{
	VACIA = 0,
	NO_VACIA = 1
}estado_e;

pila_t* crearPila(){
	pila_t * pPila = malloc(sizeof(pila_t));
	pPila -> cabezaPila = NULL;
	return pPila;
}

estado_e esPilaVacia(pila_t* pPila){
	if(pPila -> cabezaPila == NULL){
		return VACIA;
	}else{
		return NO_VACIA;
	}
}

void pushPila(pila_t* pPila, int valor){
	nodo_t * nuevoNodo = malloc(sizeof(nodo_t));
	if (nuevoNodo == NULL){
		printf("No hubo memoria suficiente para crear el nodo\n");
	}else{
		nuevoNodo -> valor = valor;
		if(esPilaVacia(pPila) == VACIA){
			nuevoNodo -> pSgte = NULL;
		}else{
			nuevoNodo -> pSgte = pPila -> cabezaPila;
			
		}
		pPila -> cabezaPila = nuevoNodo;
	}

}


void main()
{
	pila_t* pPila = crearPila();
}