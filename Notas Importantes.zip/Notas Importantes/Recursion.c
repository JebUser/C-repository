//Recursio, algo de recurrir

//contar multiplos de 3 A-B
//sumar multiplos de 3
#include <stdio.h>
int sumarMults3(int nI, int nS);


int conMults3(int n){
    if(n == 3){
        return 1; // Aumento contador porque si es multiplo y 3
    }
    else if (n%3 == 0){
        return 1 + conMults3(n-1); // Es multiplo pero es mayor a 3 y se va restando
    }
    else{
        return conMults3(n-1); // No es multiplo de 3 pero si es mayor a 3, se va restando
    }
}

int sumarMults3(int nI, int nS){
    if(nS == nI){
        if(nS %3 == 0){
            return nS;
        }
        else{
            return 0;
        }
    }
    else if(nS % 3 == 0){
        return nS + sumarMults3(nI, nS-1);
    }
    else{
        return sumarMults3(nI, nS-1);
    }
}

int sacarfacorial(int n){
    if(n == 1){
        return 1;
    }
    else{
        return n*sacarfacorial(n-1);
    }
}
// Imprimir numeros descendientes desde un lim sup a inf
// resolver la seria fibonacci para imprimir el n-termino de la seria
// 

int main(){
    int S, I, N;
    printf("Ingrese rangos:\n");
    scanf("%d", &I);
    scanf("%d", &S);
    printf("La suma de los multimos de 3 es %d", sumarMults3(I, S));
    printf("Ingrese numero: ");
    scanf("%d", &N);
    printf("El factorial de %d es %d", N, sacarfacorial(N));
    return 0;
}