/*
Guarda
#ifndef NOMBRECABECERA
#DEFINE NOMBRECABECERA
...
#endif
*/