#include <stdio.h>
#include <stdlib.h>


typedef struct Video{
    char nombre[40];
    char genero[40];
    int anio;
    int tipoVideo;
}Video_t;

Video_t *crearArreglo(void);
void *llenarStruct(Video_t *nuevoVideo);
void llenarArreglo(Video_t *Peliculas);
void imprimir(Video_t *lista);

Video_t *crearArreglo(void){
    Video_t *arreglo = malloc(5* sizeof(Video_t));
    return arreglo;
}

void *llenarStruct(Video_t *nuevoVideo){
    printf("Ingrese nombre pelicula:\n");
    fflush(stdin);
    fgets(nuevoVideo->nombre, 40, stdin);
    printf("Ingrese genero pelicula:\n");
    fflush(stdin);
    fgets(nuevoVideo->genero, 40, stdin);
    printf("Ingrese Anio de la pelicula:\n");
    scanf("%d", &nuevoVideo->anio);
    printf("Ingrese tipo de la pelicula:\n");
    printf("1. A\n");
    printf("2. B\n");
    printf("3. C\n");
    printf("4. D\n");
    scanf("%d", &nuevoVideo->tipoVideo);
}

void llenarArreglo(Video_t *Peliculas){
    llenarStruct(Peliculas);
}

void imprimir(Video_t *lista){
    for(int i = 0; i < 5; i++){
        printf("hola");
        printf("peli %s\n", lista[i].nombre);
        if(lista[i].anio == 2021){
            printf("peli %s\n", lista[i].nombre);
        }
    }
}

void main(){
    Video_t *peliculas = crearArreglo();

    for(int i = 0; i < 5; i++){
        llenarArreglo(&peliculas[i]);
    }
    printf("%s", peliculas[2].nombre);
    imprimir(peliculas);
}