#include <stdlib.h>
#include <stdio.h>

typedef struct Nodo{
    int data;
    struct Nodo *next;
}Nodo;

typedef struct Lista{
    int size;
    Nodo *head;
    void (*push)(struct Lista*, int);
}Lista;

Nodo *crearNodo(int data);
Lista crearLista();
void push(Lista *l, int data);

Nodo *crearNodo(int data){
    Nodo *nuevoNodo = (Nodo*)malloc(sizeof(Nodo));
    nuevoNodo->data = data;
    nuevoNodo->next = NULL;

    return nuevoNodo;
}

Lista crearLista(){
    Lista nuevaLista;
    nuevaLista.size = 0;
    nuevaLista.head = NULL;
    return nuevaLista;
}

void push(Lista *l, int data){
    Nodo *nuevoNodo = crearNodo(data);
    if(l->size == 0){
        l->head = nuevoNodo;
    }
    else{
        Nodo *nodo = l->head;
        while(nodo->next != NULL){
            nodo = nodo->next;
        }

        nodo->next = nuevoNodo;
    }
    l->size += 1;
}


int main(){
    Lista Lista = crearLista();
    Lista.push(&Lista, 5);
    Lista.push(&Lista, 4);
    Lista.push(&Lista, 3);
    Lista.push(&Lista, 51);
    Lista.push(&Lista, 54);
    Nodo *nodo = Lista.head;
    for (int i = 0; i < Lista.size; i++){
        printf("%d. %d\n", i + 1, nodo->data);
        nodo = nodo->next;
    }
    return 0;
}