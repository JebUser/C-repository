/*
CADENAS DE TEXTO

Se escriben con ""
"JHON DOE"

Inicialización
char nombre[9] = "Jhon doe"; Siempre se le asigna uno demas +1
char nombre[9] = {'J', 'h', 'o', 'n', '', 'd', 'o', 'e', '\0'}
char nombre[] = "Jhon doe" --- lo hace automaticamente

acceder al nombre de la cadena: nombre[#]
asignar letra a una posicion de la cadena nombre[#] = 'T'
se usa #stdio.h
fgets(char *s, int maxNChars, FILE *stream) --> usa para leer cadenas
puts(char *s)

string.h
strcpy(char *s1, const char *s2), donde s2 se copia en s1
strcat(char *s1, const char *s2), donde s2 se concatena con s1
strcmp(const char *s1, const char *s2) donde se comparan 2 cadenas y retorna 0 si son iguales y 1 o -1 si son diferentes
strchr(const char *s, int c) se busca caracter en arreglo
strstr(const char *s1, const char *s2) ocurrencia de una cadena en otra
strtok(char *s1, const char *s2), s1 es la cad a tokenizar y s2 la cadena divisoria

*/