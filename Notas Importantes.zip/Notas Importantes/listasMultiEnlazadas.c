/*
LISTAS DOBLEMENTE ENLAZADAS

typedef struct nodo{
    int valor
    struct nodo *pSgte;
    struct nodo *pAnterior;
}nodo;


typedef struct{
    nodo_t *pCabeza, *pCola;
}lista_doble;
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct numero{
    int valor;
    struct nodo *pSgte;
    struct nodo *pAnterior;
}numero;

typedef struct Lista{
    numero *pCabeza, *pCola;
}l;

l *crearLista(){
    l *nuevaLista = malloc(5*sizeof(numero));
    nuevaLista->pCabeza = NULL;
    nuevaLista->pCola = NULL;
    return nuevaLista;
}

int listaVacia(l *lista){
    if(lista ->pCabeza == NULL && lista -> pCola == NULL){
        return 1;
    }
    else{
        return 0;
    }
}

l *agregarLista(l *li, int valor){
    numero *nuevoNodo = (numero*) malloc(sizeof(numero));
    if(nuevoNodo == NULL){
        printf("No se pudo \n");
        return li;
    }
    else{
        nuevoNodo -> valor = valor;
        if(listaVacia(li) == 1){
            nuevoNodo -> pSgte = NULL;
            nuevoNodo -> pAnterior = NULL;
            li -> pCabeza = nuevoNodo;
            li -> pCola = nuevoNodo;
        }
        else{
            l *nodoAux = li -> pCabeza;
            while(nodoAux->pCola != NULL){
                nodoAux = nodoAux->pSgte;
            }
            nuevoNodo -> pSgte = NULL;
            nuevoNodo -> pAnterior = nodoAux;
            nodoAux -> pSgte = nuevoNodo;
            li -> pCola = nuevoNodo;
        }
    }
    return li;
    
}

void imprimirLista(l *lista){
    numero *nodoAux = lista -> pCabeza;
        while(nodoAux->pSgte != NULL){
            printf("-> %d <- \n", lista->pCabeza);
            nodoAux = nodoAux->pSgte;
        }
}

int main(){
    l *listaNums = crearLista();
    agregarLista(listaNums, 8);
    agregarLista(listaNums, 8);
    agregarLista(listaNums, 3);
    agregarLista(listaNums, 5);
    imprimirLista(listaNums);
    return 0;
}