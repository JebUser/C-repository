//clase 23/03/22
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct nodo{
    int valor;
    struct nodo* pSget;
}nodoT;


nodoT *insertarNodoInicio(nodoT *pCabeza, int valor){ // estoy creando el nodo, saludos 
    // crear el nuevo nodo y reservar el espacio de memoria 
    nodoT *pNuevoNodo = (nodoT*) malloc(sizeof(nodoT));
    if(pNuevoNodo == NULL){
        printf("No fue posible reservar memoria para el nuevo nodo");
        return pCabeza;
    }
    else{
        pNuevoNodo -> valor = valor;
    }
    pNuevoNodo -> pSget = pCabeza; // el nuevo nodo apuntara a la cabeza 
    pCabeza = pNuevoNodo; // la cabeza apunta a este nuevo nodo 
    return pCabeza;
}

void imprimirLista(nodoT *pCabeza){
    nodoT *pAux = pCabeza;
    while (pAux != NULL)
    {
        printf("-> %d <-\n", pAux->valor);
        pAux = pAux ->pSget;
    }
}
void contarNodosListas(nodoT *pCabeza){
    int contador = 0;
    nodoT *pAux = pCabeza;
    while(pAux != NULL){
        contador += 1;
        pAux = pAux ->pSget;
    }
    printf("Hay esta cantidad de nodos en la lista: %d\n", contador);
}
void promedioNodos(nodoT *pCabeza){
    int contador = 0;
    int promedio = 0;
    int promedioFinal = 0;
    nodoT *pAux = pCabeza;
    while(pAux != NULL){
        contador += 1;
        promedio += pAux -> valor;
        pAux = pAux ->pSget;
    }
    promedioFinal = (promedio / contador);
    printf("la suma es : %d\n", promedio);
    printf("El promedio es : %d\n", promedioFinal);
}

int existeNodo(nodoT *pCabeza, int valor){
    nodoT *pAux = pCabeza;
    while(pAux != NULL){
        if(pAux-> valor == valor){
            printf("Esta\n");
            return 1;
        }
        pAux = pAux ->pSget;
    }

    return 0;
}

nodoT *eliminaNodo(nodoT *pCabeza, int valor){
    if(existeNodo(pCabeza,valor) == 0){
        return pCabeza;
    }
    else{
        nodoT *pAux = pCabeza;
        nodoT *pTemp = pAux ->pSget;
        if(pAux -> valor == valor){ // eliminar la cabeza 
            pCabeza = pTemp;
            free(pAux);
            return pCabeza;
        }
        else{
            while(pTemp -> valor != valor){
                pAux = pTemp;
                pTemp = pTemp ->pSget;
            }
            pAux -> pSget = pTemp ->pSget;
            free(pTemp);
            return pCabeza;
        }
    }
}
/* poppila
void popPila(pilaP *pPila, int tam){
    nodo *pAux = (nodo*)malloc(sizeof(nodo));
    nodo *pTemp = (nodo*)malloc(sizeof(nodo));
    pAux = pPila->pCabezaPila->pSgte;
    pTemp = pPila->pCabezaPila;
    for(int i = 0; i < tam; i++){
        pPila->pCabezaPila = pAux;
        free(pTemp);
        pAux = pPila->pCabezaPila->pSgte;
        pTemp = pPila->pCabezaPila;
    }
    
}
*/

int main(){
    nodoT *pCabeza = NULL;
    for(int i = 10; i>0;i--){
        pCabeza = insertarNodoInicio(pCabeza,i);
    }
    imprimirLista(pCabeza);
    contarNodosListas(pCabeza);
    promedioNodos(pCabeza);
    //existeNodo(pCabeza,11);
    pCabeza = eliminaNodo(pCabeza,8);
    printf("Se elimino\n");
    imprimirLista(pCabeza);

}