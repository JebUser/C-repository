#include <stdio.h>
#include <unistd.h>

void bromita(){
    int i;
    printf("Hola tu computador ha sido bloqueado\n");
    printf("Para desbloquearlo has esta operacion (30-4)/2\n");
    printf("Procura usar solo numeros\n");
    do{
        printf("Ingresa resultado: ");
        scanf("%d", &i);
        if(i == 13){
            printf("Agarramela que me la crece, te falta calle XDXDXDXD");
        }
        else if(i != 13){
            printf("Como te veo bien pendejo, te dejare hacerlo las veces que quieras\n\a");
            
        }
    }
    while(i != 13);
    return;
}
int main(){
    bromita();
    sleep(30);
    return 0;
}