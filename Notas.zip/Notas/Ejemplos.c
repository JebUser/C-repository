#include <stdio.h>
#define True 1 //Para definir constante simbólica
#define False 0

int main (){

    int edad = 18;
    if (edad >= 18) {
        printf("Mayor de edad\n");
    }
    else {
        printf("Menor de edad\n");
    }
    int esMayor = edad >= 18 ? 1 : 0; //If else en una linea con el "?" operador ternario
    int esMayor2 = edad >=18 ? True : False;
    printf("Mayor de edad1 es: %d y el otro es: %d",esMayor, esMayor2);
    return 0;
}