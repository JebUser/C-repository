// Inicio del código
#include <stdio.h>
// Función principal
int suma(int a, int b);

int c = 10;
int d = 12;

int suma(int a, int b){
    return a+b;
}

int main(){
    printf("%d", suma(c,d));
    return 0;
}
