#include <stdio.h>

int main() {
    int respuesta;
    while (respuesta != 5){
        printf("Selecciona opcion\n");
        printf("1. Caminar\n ");
        printf("2. Inventario\n ");
        printf("3. Bestiario\n ");
        printf("4. Guardar\n ");
        printf("5. Salir\n");
        scanf("%d", &respuesta); //& direccion de memoria del teclado

        switch(respuesta) {
            case 1:
                printf("Caminando...\n");
                break;
            case 2:
                printf("Revisando Inventario...\n");
                break;
            case 3:
                printf("Revisando el bestiario...\n");
                break;
            case 4:
                printf("Guardando...\n");
                break;
            case 5:
                printf("Saliendo...\n");
            default:
                printf("Numero invalido...\n");
        }
    }
    return 0;
}