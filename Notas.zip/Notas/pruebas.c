#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef enum { VACIA = 0, NO_VACIA = 1, SI = 1, NO = 0 } estado_e;

// Dato de jugador
typedef struct Jugador {
  char nombre;
  int puntuacion;
  int id;
} jugador_t;

// Dato de la casilla
typedef struct casilla {
  int puntos;
  int inicio;
  int fin;
  int tunel;
  int cambio;
  int jugador;
} casilla_t;

// Nodo de cada casilla
typedef struct nodoLista {
  casilla_t casilla;
  struct nodoLista *pSgte;
  struct nodoLista *pTunel;
} nodo_lista_t;

// La lista/Tablero
typedef struct lista {
  nodo_lista_t *pCabeza;
} lista_t;


//prototipos
void imprimirTablero(lista_t *L);
void agregarTablero(lista_t *L);
void agregarPuentes(lista_t *L, int p1, int p2, int p3);
nodo_lista_t *crearNodo(int puntos, int inicial, int final, int cambio, int puente, int jugador);
casilla_t crearCasilla(int puntos, int inicial, int final, int cambio, int puente, int jugador);
lista_t *crearLista();
int eslistaVacia(lista_t *l);

//Verifica que la lista/tablero este vacio
int eslistaVacia(lista_t *l) {
  if (l->pCabeza == NULL) {
    return VACIA;
  } else {
    return NO_VACIA;
  }
}

//crea el tablero/lista
lista_t *crearLista() {
  lista_t *nuevaLista = (lista_t *)malloc(sizeof(lista_t));
  if (nuevaLista == NULL) {
    printf("No se pudo reservar el espacio de memoria");
  } else {
    nuevaLista->pCabeza = NULL;
  }
  return nuevaLista;
}

//Crea las casillas del tablero
/*Recibe en todas las variables SI = 1 Y NO = 0 para ver que funcion cumple esa casilla, excepto la de los puntos que recibe un numero entre el 1 al 10*/
casilla_t crearCasilla(int puntos, int inicial, int final, int cambio,
                       int puente, int jugador) {
  casilla_t nuevaCasilla;
  nuevaCasilla.puntos = puntos;
  nuevaCasilla.inicio = inicial;
  nuevaCasilla.fin = final;
  nuevaCasilla.tunel = puente;
  nuevaCasilla.jugador = jugador;
  nuevaCasilla.cambio = cambio;
  return nuevaCasilla;
}

nodo_lista_t *crearNodo(int puntos, int inicial, int final, int cambio,
                        int puente, int jugador) {
  nodo_lista_t *nuevoNodo = (nodo_lista_t *)malloc(sizeof(nodo_lista_t));
  if (nuevoNodo == NULL) {
    printf("No se pudo reservar el espacio de memoria");
  } else {
    nuevoNodo->casilla =
        crearCasilla(puntos, inicial, final, cambio, puente, jugador);
    nuevoNodo->pSgte = NULL;
    nuevoNodo->pTunel = NULL;
  }
  return nuevoNodo;
}

void imprimirTablero(lista_t *L) {
  nodo_lista_t *pAux = L->pCabeza;
  int i = 1;
  while (pAux != NULL) {
    if (i % 6 != 0) {
      if (pAux->casilla.inicio == SI) {
        printf(" ||I|| ");
      } else if (pAux->casilla.fin == SI) {
        printf(" ||F|| ");
      } else if (pAux->casilla.tunel == SI) {
        printf(" ||-|| ");
      } else if (pAux->casilla.cambio == SI) {
        printf(" ||C|| ");
      } else {
        printf(" ||%d|| ", pAux->casilla.puntos);
      }
    } else {
      if (pAux->casilla.inicio == SI) {
        printf(" ||I|| \n");
      } else if (pAux->casilla.fin == SI) {
        printf(" ||F|| \n");
      } else if (pAux->casilla.tunel == SI) {
        printf(" ||-|| \n");
      } else if (pAux->casilla.cambio == SI) {
        printf(" ||C|| \n");
      } else {
        printf(" ||%d|| \n", pAux->casilla.puntos);
      }
    }
    pAux = pAux->pSgte;
    i++;
  }
}

void agregarTablero(lista_t *L) {
  srand(time(0));
  int Inicio, Final, Cambio, puente1, puente2, puente3, puntos, negativo, Nnegativos = 0, flag = 0;

  do {
    Inicio = 1 + rand() % 24;
    Cambio = 1 + rand() % 24;
    puente1 = 1 + rand() % 24;
    puente2 = 1 + rand() % 24;
    puente3 = 1 + rand() % 24;
    for (int i = 0; i < 24; i++) {
      nodo_lista_t *nuevaCasilla;
      if (i == Inicio) {
        nuevaCasilla = crearNodo(0, SI, NO, NO, NO, SI);
        flag++;
      } else if (i == 23) {
        nuevaCasilla = crearNodo(0, NO, SI, NO, NO, SI);
        flag++;
      } else if (i == Cambio) {
      
        nuevaCasilla = crearNodo(0, NO, NO, SI, NO, NO);
        flag++;
      } else if (i == puente1 || i == puente2 || i == puente3) {
        nuevaCasilla = crearNodo(0, NO, NO, NO, SI, NO);
        flag++;
      } else {
        puntos = 1 + rand() % 9;
        nuevaCasilla = crearNodo(puntos, NO, NO, NO, NO, NO);
      }
        if (eslistaVacia(L) == VACIA) {
          L->pCabeza = nuevaCasilla;
        } else {
          nodo_lista_t *pAux = L->pCabeza;
          while (pAux->pSgte != NULL) {
            pAux = pAux->pSgte;
          }
          pAux->pSgte = nuevaCasilla;
        }
    }
    if(flag != 6){
      free(L->pCabeza);
      L->pCabeza = NULL;
      flag = 0;
    }
  } while (flag != 6);
  printf("Inicio en la casilla %d\n", Inicio + 1);
  printf("Fin en la casilla %d\n", 24);
  printf("Cambio en la casilla %d\n", Cambio + 1);
  printf("Puente en la casilla %d\n", puente1 + 1);
  printf("Puente en la casilla %d\n", puente2 + 1);
  printf("Puente en la casilla %d\n", puente3 + 1);
  agregarPuentes(L, puente1, puente2, puente3);
}

void agregarPuentes(lista_t *L, int p1, int p2, int p3){
  int llegada1, llegada2, llegada3, flag = 0;
  nodo_lista_t *pAuxSalida = L->pCabeza;
  nodo_lista_t *pAuxLlegada = L->pCabeza;
  
  do{
    for(int i = 0; i < p1; i++){
      pAuxSalida = pAuxSalida->pSgte;
    }
    llegada1 = 1 + rand() % 24;
    for(int i = 0; i < llegada1; i++){
      pAuxLlegada = pAuxLlegada->pSgte;
    }
    if(pAuxLlegada->casilla.puntos != 0){
      flag++;
      pAuxSalida->pTunel = pAuxLlegada;
    }
  }while(flag != 1);
  printf("Llegada 1 en la casilla %d\n", llegada1+1);
  flag = 0;
  
  do{
    pAuxSalida = L->pCabeza;
    pAuxLlegada = L->pCabeza;
    for(int i = 0; i < p2; i++){
      pAuxSalida = pAuxSalida->pSgte;
    }
    llegada2 = 1 + rand() % 24;
    if(llegada2 != llegada1){
      for(int i = 0; i < llegada2; i++){
        pAuxLlegada = pAuxLlegada->pSgte;
      }
      if(pAuxLlegada->casilla.puntos != 0){
        flag++;
        pAuxSalida->pTunel = pAuxLlegada;
      }
    }
  }while(flag != 1);
  printf("Llegada 2 en la casilla %d\n", llegada2+1);
  flag = 0;
  
  do{
    pAuxSalida = L->pCabeza;
    pAuxLlegada = L->pCabeza;
    for(int i = 0; i < p3; i++){
      pAuxSalida = pAuxSalida->pSgte;
    }
    llegada3 = 1 + rand() % 24;
    if(llegada3 != llegada2 && llegada3 != llegada1){
      for(int i = 0; i < llegada3; i++){
        pAuxLlegada = pAuxLlegada->pSgte;
      }
      if(pAuxLlegada->casilla.puntos != 0){
        flag++;
        pAuxSalida->pTunel = pAuxLlegada;
      } 
    } 
  }while(flag != 1);
  printf("Llegada 3 en la casilla %d\n", llegada3+1);
}

int main(void) {
  lista_t *Tablero = crearLista();
  agregarTablero(Tablero);
  imprimirTablero(Tablero);
  return 0;
}