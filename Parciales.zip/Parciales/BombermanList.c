//Autor: Juan Esteban Becerra Gutiérre

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


typedef struct nodo{
    int ob_casilla;
    int casilla;
    struct nodo *pSgte;
}nodo;

nodo *insertarNodoInicio(nodo *pCabeza, int obj, int cas);
void BomberGame();
void imprimirTablero(nodo *pCabeza, int filas);
nodo *moverJugador(nodo *pCabeza, int mov, int cas);
int verificarGanador(nodo *pCabeza);
int pisoBomba(nodo *pCabeza);
nodo *quitarCasilla(nodo *pCabeza, int bomba, int casillas);
nodo *ponerNuevaBomba(nodo *pCabeza, int casillas);


nodo *insertarNodoInicio(nodo *pCabeza, int obj, int cas){ 
    nodo *pNuevoNodo = (nodo*) malloc(sizeof(nodo));
    if(pNuevoNodo == NULL){
        printf("No fue posible reservar memoria para el nuevo nodo");
        return pCabeza;
    }
    else{
        pNuevoNodo -> ob_casilla = obj;
        pNuevoNodo -> casilla = cas;
    }
    pNuevoNodo -> pSgte = pCabeza; 
    pCabeza = pNuevoNodo; 
    return pCabeza;
}

nodo* moverJugador(nodo *pCabeza, int mov, int cas){
    nodo *pAux = pCabeza;
    nodo *pInicial = pCabeza;
    int casAct, mov2;
    while(pAux != NULL){
        if(pAux->ob_casilla == 1){
            pAux->ob_casilla = 0;
            casAct = pAux->casilla;
            break;
        }
        pAux = pAux ->pSgte;
    }
    for(int i = 0; i < mov; i++){
        if(casAct+mov > cas){
            pAux = pInicial;
            mov2 = casAct+mov - cas-1;
            for(int j = 0;j < mov2;j++){
                pAux = pAux->pSgte;
            }
        }
        else{
            pAux = pAux->pSgte;
        }
    }
    pAux->ob_casilla = 1;
    printf("CASILLA ACTUAL %d\n", pAux->casilla);
    return pCabeza;
}

void imprimirTablero(nodo *pCabeza, int filas){
    nodo *pAux = pCabeza;
    int i = 1;
    while (pAux != NULL){
        if(i % filas != 0){
            printf(" ||%d-%d|| ", pAux->casilla, pAux->ob_casilla);
        }
        else{
            printf(" ||%d-%d|| \n", pAux->casilla, pAux->ob_casilla);
        }
        pAux = pAux ->pSgte;
        i++;
    }
}

nodo *quitarCasilla(nodo *pCabeza, int bomba, int casillas){
    nodo *pAux = pCabeza;
    nodo *pTemp = pAux ->pSgte;
    while(pTemp -> ob_casilla != bomba){
        pAux = pTemp;
        pTemp = pTemp ->pSgte;
    }
    pAux -> pSgte = pTemp ->pSgte;
    free(pTemp);
    return pCabeza;
}

int pisoBomba(nodo *pCabeza){
    nodo *pAux = pCabeza;
    int flag = 1;
    while (pAux != NULL){
        if(pAux->ob_casilla == 88){
            flag = 0;
        }
        pAux = pAux ->pSgte;
    }
    return flag;
}

nodo *ponerNuevaBomba(nodo *pCabeza, int casillas){
    int nb, flag3 = 0;
    nodo *pAux = pCabeza;
    srand(time(0));
    do{
        do{
            nb = rand() % casillas;
        }
        while(nb == 0);
        for(int i = 0; i < casillas; i++){
            if(i == nb){
                printf("Hay una nueva bomba en la casilla %d\n", pAux->casilla);
                pAux->ob_casilla = 88;
                flag3 = 1;
                break;
            }
            pAux = pAux->pSgte;
        }
    }
    while(flag3 == 0);
    return pCabeza;

}


int verificarGanador(nodo *pCabeza){
    nodo *pAux = pCabeza;
    int flag = 0;
    while (pAux != NULL){
        if(pAux->ob_casilla == 10){
            flag = 1;
        }
        pAux = pAux ->pSgte;
    }
    return flag;
}

void BomberGame(){
    int b1, w, f, dado, nb, casillas, turnos = 0, ganar = 0, perder;
    int flag1 = 0, flag2 = 0;
    srand(time(0));
    printf("BIENVENIDO AL JUEGO DE BOMBERMAN LIST\nLAS CASILLAS MUESTRAS SU NUMERO Y SU RESPECTIVO OBJETO A LA DERECHA\nLAS CASILLA CON 88 TIENE BOMBA Y LA QUE CONTIENE AL 10 ES LA GANADORA, EL JUGADOR ES EL NUMERO 1\n");
    printf("PARA GANAR DEBES CAER EN LA CASILLA CON EL 10 PERO SI TE QUEDAN 3 CASILLAS PIERDES\n");
    do{
        printf("Ingrese filas, minimo 3\n");
        scanf("%d", &f);
        if(f <=2){
            printf("Numero de filas no validas\n");
        }
    }
    while(f <= 2);
    perder = f*f;
    casillas = f*f;
    nodo *Tablero = NULL;
    do{
        do{
            b1 = rand() % casillas;
            w = rand() % casillas;
        }
        while(b1 == w);
        for(int i = 0; i < casillas; i++){
            if(i == b1){
                Tablero = insertarNodoInicio(Tablero, 88, casillas-i);
                printf("Hay una bomba en la casilla %d\n", Tablero->casilla);
                flag1 = 1;
            }
            else if(i == w){
                Tablero = insertarNodoInicio(Tablero, 10, casillas-i);
                printf("La casilla ganadora es la casilla %d\n", Tablero->casilla);
                flag2 = 1;
            }
            else if(i == casillas-1){
                Tablero = insertarNodoInicio(Tablero, 1, 1);
            }
            else{
                Tablero = insertarNodoInicio(Tablero, 0, casillas-i);
            }
        }
    }
    while(flag1 == 0 && flag2 == 0);
    
    imprimirTablero(Tablero, f);
    do{
        printf("Tira el dado\n");
        system("Pause");
        printf("\n");
        dado = 1 + rand() % 6;
        printf("SACO %d\n", dado);
        Tablero = moverJugador(Tablero, dado, casillas);
        imprimirTablero(Tablero, f);
        printf("\n");
        if(pisoBomba(Tablero) == 1){

            Tablero = quitarCasilla(Tablero, 1, casillas);
            Tablero->ob_casilla = 1;
            casillas--;

            Tablero = ponerNuevaBomba(Tablero, casillas);
            imprimirTablero(Tablero, f);
            printf("\n");
            perder--;
        }
        if(verificarGanador(Tablero) == 0){
            printf("Ganaste!\n");
            ganar = 1;
        }
        turnos++;
        
        if(perder == 2){
            printf("Perdiste por destruccion del terreno\n");
        }
    }
    while(ganar != 1 || perder == 2);
    printf("Has jugado %d turnos", turnos);
}

int main(){
    BomberGame();
    return 0;
}