//Código desarrollado por: Juan Esteban Becerra
//Punto a desarrollar: 1

#include <stdio.h>
#include <stdlib.h>

typedef struct item{
    char nombre[30];
    char tipo[30];
    char descripcion[100];
    struct item *pSgte;
}item;

typedef struct lista{
    int tamano;
    item *pCabeza;
}lista;

void menuInventario(lista inventario);
void imprimirLista(lista *L);
void agregarItems(lista *L);
void quitarItem(lista *L, int itemEl);
item *crearItem(void);
lista crearLista(void);

lista crearLista(){
    lista nuevaLista;
    nuevaLista.tamano = 0;
    nuevaLista.pCabeza = NULL;
    return nuevaLista;
}

item *crearItem(void){
    item *nuevoItem = (item*)malloc(sizeof(item));
    printf("Ingrese nombre menor a 30 caracteres, los espacios cuentan\n");
    fflush(stdin);
    fgets(nuevoItem->nombre, 30, stdin);
    printf("Ingrese tipo menor a 30 caracteres, los espacios cuentan:\n");
    fflush(stdin);
    fgets(nuevoItem->tipo, 30, stdin);
    printf("Ingrese descripicion menor a 100 caracteres, los espacios cuentan:\n");
    fflush(stdin);
    fgets(nuevoItem->descripcion, 100, stdin);
    nuevoItem->pSgte = NULL;
    return nuevoItem;
}

void agregarItems(lista *L){
    item *nuevoItem = crearItem();
    if(L->tamano == 0){
        L->pCabeza = nuevoItem;
        L->tamano += 1;
        printf("Se agrego el item\n");
    }
    else{
        item *pAux = L->pCabeza;
        while(pAux->pSgte != NULL){
            pAux = pAux->pSgte;
        }

        pAux->pSgte = nuevoItem;
        L->tamano += 1;
        printf("Se agrego el item\n");
    }

}

void imprimirLista(lista *L){
    int n = 0;
    if(L->pCabeza == NULL){
        printf("El inventario esta vacio, agrega items\n");
    }
    else{
        item *pAux = L->pCabeza;
        while(n < L->tamano){
            printf("=====================================\n");
            printf("Item %d:\n", n+1);
            printf("    Nombre: %s\n", pAux->nombre);
            printf("    Tipo: %s\n", pAux->tipo);
            printf("    Descripcion: %s\n", pAux->descripcion);
            pAux = pAux->pSgte;
            n++;
        }
        printf("=====================================\n");
    }
}

void quitarItem(lista *L, int itemEl){
    int n = 2;
    item *pAux = L->pCabeza;
    item *pTemp = pAux->pSgte;
    if(itemEl == 1){
        L->pCabeza = pTemp;
        free(pAux);
        printf("Se elimino el item\n");
        L->tamano -=1;
        return;
    }
    else{
        while(n < itemEl){
            pAux = pTemp;
            pTemp = pTemp->pSgte;
            n++;
        }
        pAux->pSgte = pTemp->pSgte;
        free(pTemp);
        printf("Se elimino el item\n");
        L->tamano -=1;
        return;
    }
}

void menuInventario(lista inventario){
    int opc, itemPos;
    do{
        printf("Bienvenido al inventario\n");
        printf("1. Ver los items\n");
        printf("2. Agregar items\n");
        printf("3. Quitar item\n");
        printf("4. Salir\n");
        printf("Seleccione opcion: ");
        scanf("%d", &opc);
        printf("\n");
        switch (opc){
        case 1:
            imprimirLista(&inventario);
            break;
        case 2:
            agregarItems(&inventario);
            break;
        case 3:
            if(inventario.tamano != 0){
                do{
                    printf("Indique el numero del item de la lista a remover: ");
                    scanf("%d", &itemPos);
                    if(itemPos > inventario.tamano){
                        printf("Numero no valido, ingrese otro");
                    }
                }
                while(itemPos > inventario.tamano);
                quitarItem(&inventario, itemPos);
                printf("\n");
            }
            else{
                printf("No hay items para eliminar\n");
            }
            break;
        case 4:
            break;
        default:
            printf("Opcion no valida, ingrese otra\n");
            break;
        system("pause");
        system("cls");
        }
    }
    while(opc != 4);
    return;
}

int main(){
    lista inventario = crearLista();
    menuInventario(inventario);
    return 0;
}