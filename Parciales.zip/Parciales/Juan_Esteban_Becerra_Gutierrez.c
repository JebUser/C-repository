//PARCIAL 1
//JUAN ESTEBAN BECERRA GUTIÉRREZ
//Librerias
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//===================================================
//PUNTO 1
//PROTOTIPOS
void menuPrincipal(void);
void menuInventario(void);
void printItems(void);
void menuTienda(void);
void tienda(void);

//VARIABLES GLOBALES
int dinero = 10000;
char inventario[15] = "";
int contT = 0;
//FUNCIONES
void printItems(void){
    int cont = 1;
    printf("=====================================\n");
    for(int i = 0; i < contT; i++)
        printf("%d. Item: %C\n", i+1, inventario[i]);
    printf("=====================================\n");
    return;
}
void menuInventario(void){
    int opc;
    do{
        printf("Bienvenido al inventario\n");
        printf("1. Ver los items\n");
        printf("2. Salir al menu principal\n");
        printf("Seleccione opcion: ");
        scanf("%d", &opc);
        switch (opc){
        case 1:
            if(contT != 0){
                printItems();
            }
            else{
                printf("\nTu inventario esta vacio, mejor ve y compra items pobre de mierda\n\n");
            }
            break;
        case 2:
            printf("Volviendo al menu principal\n");
            break;
        default:
            printf("Opcion no valida, ingrese otra\n");
            break;
        }
    }
    while(opc != 2);
    return;
}
void tienda(void){
    int it;
    int totalItems1;
    do{
        totalItems1 = contT;
        printf("Estos son los items:\n");
        printf("1. A ------> 50\n");
        printf("2. B ------> 70\n");
        printf("3. C ------> 150\n");
        printf("4. D ------> 20\n");
        printf("5. E ------> 2000\n");
        printf("6. Cancelar\n");
        printf("Escoja el item: ");
        scanf("%d", &it);
        if(totalItems1 < 15){
            switch (it){
            case 1:
                if(dinero >= 50){
                    inventario[contT] = 'A';
                    contT++;
                    dinero-= 50;
                    printf("Gracias por comprar el item A\n");
                }
                else{
                    printf("Dinero insuficiente\n");
                }
                break;
            case 2:
                if(dinero >= 70){
                    inventario[contT] = 'B';
                    contT++;
                    dinero-= 70;
                    printf("Gracias por comprar el item B\n");
                }
                else{
                    printf("Dinero insuficiente\n");
                }
                break;
            case 3:
                if(dinero >= 150){
                    inventario[contT] = 'C';
                    contT++;
                    dinero-= 150;
                    printf("Gracias por comprar el item C\n");
                }
                else{
                    printf("Dinero insuficiente\n");
                }
                break;
            case 4:
                if(dinero >= 20){
                    inventario[contT] = 'D';
                    contT++;
                    dinero-= 20;
                    printf("Gracias por comprar el item D\n");
                }
                else{
                    printf("Dinero insuficiente\n");
                }
                break;
            case 5:
                if(dinero >= 2000){
                    inventario[contT] = 'E';
                    contT++;
                    dinero-= 2000;
                    printf("Gracias por comprar el item E\n");
                }
                else{
                    printf("Dinero insuficiente\n");
                }
                break;
            case 6:
                printf("Cancelando...\n");
                break;
            default:
                printf("Opcion no valida, ingrese otra\n");
                break;
            }
        }
        else{
            printf("Inventario lleno, no se puede comprar mas");
            it = 6;
        }
    }
    while(it != 6);
    return;
}

void menuTienda(void){
    int opI;
    int totalItems = contT;
    do{
        printf("\nBienvenido a la tienda\n");
        printf("1. Ver saldo\n");
        printf("2. Comprar items\n");
        printf("3. Salir de la tienda\n");
        printf("Escoja la accion: ");
        scanf("%d", &opI);
        switch (opI){
        case 1:
            printf("\nTu saldo es: %d\n", dinero);
            break;
        case 2:
            if(totalItems < 15){
                tienda();
            }
            else{
                printf("No se pueden comprar mas items, inventario lleno");
            }
            break;
        case 3:
            printf("Saliendo de la tienda...\n");
            break;
        default:
            printf("Opcion no valida, ingrese otra\n");
            break;
        }
    }
    while(opI != 3);
    return;
}
void menuPrincipal(void){
    int op;
    do{
        printf("Acciones\n");
        printf("1. Inventario\n");
        printf("2. Tienda\n");
        printf("3. Salir\n");
        printf("Seleccione opcion: ");
        scanf("%d", &op);
        switch (op){
        case 1:
            menuInventario();
            break;
        case 2:
            menuTienda();
            break;
        case 3:
            printf("Saliendo...");
            break;
        default:
            printf("Opcion no valida, ingrese otra\n");
            break;
        } 
    }
    while(op != 3);
    return;
}
//==========================================
//Punto 2
//Prototipos
void juegoTriqui(void);
void agregarTablero(int selec);
void victoria(void);
//Variables
char tablero[3][3] = {{'-','-','-'}, {'-','-','-'}, {'-','-','-'}};
char selMach = 'O';
char selJ = 'O';
int turnos = 1;
int i, j, iM, jM, flag;
int ganadorJ = 0;
int ganadorMach = 0;
//Funciones

void victoria(){
    if(tablero[0][0] == 'X' || tablero[0][0] == 'O'){
        if(tablero[0][0] == tablero[0][1] && tablero[0][0] == tablero[0][2]){
            if(tablero[0][0] == selJ){
                ganadorJ = 1;
            }
            else{
                ganadorMach = 1;
            }
        }
        else if(tablero[0][0] == tablero[1][0] && tablero[0][0] == tablero[2][0]){
            if(tablero[0][0] == selJ){
                ganadorJ = 1;
            }
            else{
                ganadorMach = 1;
            }
        }
    }
    if(tablero[1][1]=='X' || tablero[1][1] == 'O'){
        if(tablero[1][1] == tablero[0][0] && tablero[1][1] == tablero[2][2]){
            if(tablero[1][1] == selJ){
                ganadorJ = 1;
            }
            else{
                ganadorMach = 1;
            }
        }
        else if(tablero[1][1] == tablero[1][0] && tablero[1][1] == tablero[1][2]){
            if(tablero[1][1] == selJ){
                ganadorJ = 1;
            }
            else{
                ganadorMach = 1;
            }
        }
        else if(tablero[1][1] == tablero[2][0] && tablero[1][1] == tablero[0][2]){
            if(tablero[1][1] == selJ){
                ganadorJ = 1;
            }
            else{
                ganadorMach = 1;
            }
        }
        else if(tablero[1][1] == tablero[0][1] && tablero[1][1] == tablero[2][1]){
            if(tablero[1][1] == selJ){
                ganadorJ = 1;
            }
            else{
                ganadorMach = 1;
            }
        }
    }
    if(tablero[2][2]=='X' || tablero[2][2] == 'O'){
        if(tablero[2][2] == tablero[2][0] && tablero[2][2] == tablero[2][1]){
            if(tablero[2][2] == selJ){
                ganadorJ = 1;
            }
            else{
                ganadorMach = 1;
            }
        }
        else if(tablero[2][2] == tablero[0][2] && tablero[2][2] == tablero[1][2]){
            if(tablero[2][2] == selJ){
                ganadorJ = 1;
            }
            else{
                ganadorMach = 1;
            }
        }
    }
    return;
}
void agregarTablero(int selec){ 
    if(selec == 1){
        selMach = 'X';
    }
    else{
        selJ = 'X';
    }
    do{
        do{
            
            flag = 0;
            printf("Selecciona la fila: \n");
            scanf("%d", &i);
            printf("Selecciona la columna: \n");
            scanf("%d", &j);
            printf("\n");
            if(tablero[i-1][j-1] == '-'){
                tablero[i-1][j-1] = selJ;
                flag = 1;
                for(int f = 0; f < 3; f++){
                    for (int c = 0; c < 3; c++){
                        printf("%C\t", tablero[f][c]);
                }
                printf("\n\n");
                }
                turnos++;
            }
            else{
                printf("Fila tomada\n");
            }
        }
        while(flag == 0);
        printf("Turno de la maquina\n");
        if(turnos < 9){
            do{
                flag = 0;
                srand(time(NULL));
                iM = rand() % 3;
                jM = rand() % 3;
                if(tablero[iM][jM] == '-'){
                    tablero[iM][jM] = selMach;
                    flag = 1;
                    for(int f = 0; f < 3; f++){
                        for (int c = 0; c < 3; c++){
                            printf("%C\t", tablero[f][c]);
                    }
                    printf("\n\n");
                    }
                    turnos++;
                }
            }
            while(flag == 0);
        }
        victoria();
        
    
    }
    while(turnos <= 8 && ganadorJ == 0 && ganadorMach == 0);
    if(ganadorJ == 1){
        printf("Gano el jugador\n");
    }
    else if(ganadorMach == 1){
        printf("Gano la maquina\n");
    }
    else{
        printf("Empate");
    }
    return;
}
void juegoTriqui(void){
    int sel;
    printf("Bienvenido al juego de Triqui\n");
    printf("Seleccione figura:\n");
    printf("1. O\n");
    printf("2. X\n");
    scanf("%d", &sel);
    switch (sel){
    case 1:
        agregarTablero(sel);
        break;
    case 2:
        agregarTablero(sel);
        break;
    default:
        printf("Opcion no valida, ingrese otra");
        break;
    }
    return;
}
//MAIN
int main(){
    menuPrincipal();
    printf("\n");
    juegoTriqui();
    return 0;
}