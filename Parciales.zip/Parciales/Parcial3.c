#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
    char letra;
    struct nodo *pSgte;
}nodo;

typedef struct pila{
    int tamano;
    nodo *pCabezaPila;
}pilaP;

typedef enum{
    VACIA = 0,
    NO_VACIA = 1,
    ES_PALINDROMO = 1,
    NO_ES_PALINDROMO = 0
}estado;

void pushPila(pilaP *pPila, char letra);
void popPila(pilaP *pPila);
void verificar(pilaP pPila);
int esPalindromo(char caracter1, char caracter2);
pilaP crearPila(void);
estado esPilaVacia(pilaP *pPila);

pilaP crearPila(void){
	pilaP nuevapPila;
    nuevapPila.tamano = 0;
	nuevapPila.pCabezaPila = NULL;
	return nuevapPila;
}


estado esPilaVacia(pilaP *pPila){
	if(pPila->pCabezaPila == NULL){
		return VACIA;
	}else{
		return NO_VACIA;
	}
}

void pushPila(pilaP *pPila, char letra){
	nodo *nuevoNodo = (nodo*)malloc(sizeof(nodo));
	if (nuevoNodo == NULL){
		printf("No hubo memoria suficiente para crear el nodo\n");
	}else{
        nuevoNodo->letra = letra;
		if(esPilaVacia(pPila) == VACIA){
			nuevoNodo->pSgte = NULL;
		}else{
			nuevoNodo->pSgte = pPila->pCabezaPila;		
		}
		pPila->pCabezaPila = nuevoNodo;
        pPila->tamano++;
	}
}

void popPila(pilaP *pPila){
    if(esPilaVacia(pPila) == NO_VACIA){
        nodo *pAuxCabeza = pPila->pCabezaPila;
        nodo *pAuxSgte = pPila->pCabezaPila->pSgte;
        free(pAuxCabeza);
        pPila->pCabezaPila = pAuxSgte;
    }
    else{
        printf("No se pueden sacar nodos\n");
    }
}


void verificar(pilaP pPila){
    char char1;
    char char2;
    int verificador;
    pilaP pilaInversa = crearPila();
    pilaP pilaRep = crearPila();
    nodo *datAux;
    char char3;
    while(pPila.pCabezaPila != NULL){
        datAux = pPila.pCabezaPila;
        char3 = datAux->letra;
        popPila(&pPila);
        pushPila(&pilaInversa, char3);
        pushPila(&pilaRep, char3);
        
    }
    while(pilaRep.pCabezaPila != NULL){
        datAux = pilaRep.pCabezaPila;
        char3 = datAux->letra;
        popPila(&pilaRep);
        pushPila(&pPila, char3);
        
    }
    while(pPila.pCabezaPila != NULL){
        char1 = pPila.pCabezaPila->letra;
        char2 = pilaInversa.pCabezaPila->letra;
        verificador = esPalindromo(char1, char2);
        if(verificador == NO_ES_PALINDROMO){
            printf("No es palindromo");
            return;
        }
        popPila(&pilaInversa);
        popPila(&pPila);
    }
    printf("Es palindromo");
}

int esPalindromo(char caracter1, char caracter2){
    if(caracter1 == caracter2){
        return ES_PALINDROMO;
    }
    return NO_ES_PALINDROMO;
}



int main(){
    //
    pilaP palabra = crearPila();
    int i, num;
    char letra;
    printf("Ingrese cantidad de caracteres de la palabra:\n");
    scanf("%d", &num);
    for(i = 0; i < num; i++){
        printf("Ingrese:\n");
        fflush(stdin);
        scanf("%c", &letra);
        pushPila(&palabra, letra);
        printf("Se agrego\n");
    }
    verificar(palabra);
    return 0;
}