#include <stdio.h>
#include <time.h>
#include <stdlib.h>
void construccionArreglo(void);
int verificarRepetido(int n, int ps);
int menorArreglo(int n, int p);
int recorrerArreglo(int n2);
int cambiarNumero(int num, int p, int nC);
void pedirCambio(void);
//void recorrerLista(void); para revisar la lista final

int arreglo[300] = {};
int verificarRepetido(int n, int ps){
    for(int j = 0; j < ps; j++){
        if(n == arreglo[j]){
            return 1;
        }
    }
    return 0;
}

void construccionArreglo(void){
    int num;
    int flag;
    srand(time(NULL));
    num = 1 + rand() % 751;
    for(int i = 0; i < 300; i++){
        do{
            num = 1 + rand() % 751;
            flag = verificarRepetido(num, i);
        }
        while(flag != 0);
        arreglo[i] = num;

    }
    for(int i = 0; i < 300; i++){
        printf("%d\n", arreglo[i]);
    }
    return;
}
int recorrerArreglo(int n2){
     return arreglo[n2];
}
int menorArreglo(int n, int p){
    if(n < 751){
        if(p < 300){
            if(n == recorrerArreglo(p)){
                return menorArreglo(n+1, 0);
            }
            else{
                return menorArreglo(n, p+1);
            }
        }
        else{
            return n;
        }
    }
}
int cambiarArreglo(int num, int p, int nC){
    if(p < 300){
        if(num == recorrerArreglo(p)){
            arreglo[p] = nC;
            printf("Numero cambiado\n");
            return arreglo[p];
        }
        else{
            cambiarArreglo(num, p+1, nC);
        }
    }
    else{
        printf("Numero no encontrado\n");
        return 0;
    }
}
void pedirCambio(){
    int sel;
    printf("Ingrese numero a cambiar por el menor: ");
    scanf("%d", &sel);
    cambiarArreglo(sel, 0, menorArreglo(1,0));
    return;
}
/*
void recorrerLista(){
    for(int i = 0; i < 300; i++){
        printf("%d\n", arreglo[i]);
    }
}
*/
int main(){
    construccionArreglo();
    printf("El menor numero es: %d\n", menorArreglo(1, 0));
    pedirCambio();
    //recorrerlista(); Mira la lista actualizada
    return 0;
}