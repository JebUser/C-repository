#include "Tablero.h"

//Verifica que la lista/tablero este vacio
int eslistaVacia(lista_t *l) {
  if (l->pCabeza == NULL) {
    return VACIA;
  } else {
    return NO_VACIA;
  }
}

//crea el tablero/lista
lista_t *crearLista() {
  lista_t *nuevaLista = (lista_t *)malloc(sizeof(lista_t));
  if (nuevaLista == NULL) {
    printf("No se pudo reservar el espacio de memoria");
  } else {
    nuevaLista->pCabeza = NULL;
  }
  return nuevaLista;
}

//Crea las casillas del tablero
/*Recibe en todas las variables SI = 1 Y NO = 0 para ver que funcion cumple esa casilla, excepto la de los puntos que recibe un numero entre el 1 al 10*/
casilla_t crearCasilla(int puntos, int inicial, int final, int cambio,
                       int puente, int jugador) {
  casilla_t nuevaCasilla;
  nuevaCasilla.puntos = puntos;
  nuevaCasilla.inicio = inicial;
  nuevaCasilla.fin = final;
  nuevaCasilla.tunel = puente;
  nuevaCasilla.jugador = jugador;
  nuevaCasilla.cambio = cambio;
  return nuevaCasilla;
}

nodo_lista_t *crearNodo(int puntos, int inicial, int final, int cambio,
                        int puente, int jugador) {
  nodo_lista_t *nuevoNodo = (nodo_lista_t *)malloc(sizeof(nodo_lista_t));
  if (nuevoNodo == NULL) {
    printf("No se pudo reservar el espacio de memoria");
  } else {
    nuevoNodo->casilla = crearCasilla(puntos, inicial, final, cambio, puente, jugador);
    nuevoNodo->pSgte = NULL;
    nuevoNodo->pTunel = NULL;
  }
  return nuevoNodo;
}

void imprimirTablero(lista_t *L) {
  nodo_lista_t *pAux = L->pCabeza;
  int i = 1;
  while (pAux != NULL) {
    if (i % 6 != 0) {
      if (pAux->casilla.inicio == SI) {
        printf(" || I || ");
      } else if (pAux->casilla.fin == SI) {
        printf(" || F || ");
      } else if (pAux->casilla.tunel == SI) {
        printf(" || - || ");
      } else if (pAux->casilla.cambio == SI) {
        printf(" || C || ");
      } else if(pAux->casilla.jugador == SI){
        printf(" || J || ");
      } else {
        printf(" || %d || ", pAux->casilla.puntos);
      }
    } else {
      if (pAux->casilla.inicio == SI) {
        printf(" || I || \n");
      } else if (pAux->casilla.fin == SI) {
        printf(" || F || \n");
      } else if (pAux->casilla.tunel == SI) {
        printf(" || - || \n");
      } else if (pAux->casilla.cambio == SI) {
        printf(" || C || \n");
      } else if(pAux->casilla.jugador == SI){
        printf(" || J || \n");
      } else {
        printf(" || %d || \n", pAux->casilla.puntos);
      }
    }
    pAux = pAux->pSgte;
    i++;
  }
  printf("\n");
}

void agregarTablero(lista_t *L) {
  srand(time(0));
  int Inicio, Final, Cambio, puente1, puente2, puente3, puntos, negativo1, negativo2, negativo3, flag = 0;
  do {
    Inicio = rand() % 22;
    Cambio = rand() % 22;
    puente1 = rand() % 22;
    puente2 = rand() % 22;
    puente3 = rand() % 22;
    negativo1 = rand() % 22;
    negativo2 = rand() % 22;
    negativo3 = rand() % 22;
    for (int i = 0; i < 24; i++) {
      nodo_lista_t *nuevaCasilla;
      if (i == Inicio) {
        nuevaCasilla = crearNodo(0, SI, NO, NO, NO, SI);
        flag++;
      } else if (i == 23) {
        nuevaCasilla = crearNodo(0, NO, SI, NO, NO, SI);
        flag++;
      } else if (i == Cambio) {
        nuevaCasilla = crearNodo(0, NO, NO, SI, NO, NO);
        flag++;
      } else if (i == puente1 || i == puente2 || i == puente3) {
        nuevaCasilla = crearNodo(0, NO, NO, NO, SI, NO);
        flag++;
      } else if(i == negativo1 || i == negativo2 || i == negativo3){
        puntos = (-1)*(1 + rand() % 4);
        nuevaCasilla = crearNodo(puntos, NO, NO, NO, NO, NO);
        flag++;
      } else {
        puntos = 1 + rand() % 9;
        nuevaCasilla = crearNodo(puntos, NO, NO, NO, NO, NO);
      }
        if (eslistaVacia(L) == VACIA) {
          L->pCabeza = nuevaCasilla;
        } else {
          nodo_lista_t *pAux = L->pCabeza;
          while (pAux->pSgte != NULL) {
            pAux = pAux->pSgte;
          }
          pAux->pSgte = nuevaCasilla;
        }
    }
    if(flag != 9){
      free(L->pCabeza);
      L->pCabeza = NULL;
      flag = 0;
    }
  } while (flag != 9);
  printf("Inicio en la casilla %d\n", Inicio + 1);
  printf("Fin en la casilla %d\n", 24);
  printf("Cambio en la casilla %d\n", Cambio + 1);
  printf("Puente 1 en la casilla %d\n", puente1 + 1);
  printf("Puente 2 en la casilla %d\n", puente2 + 1);
  printf("Puente 3 en la casilla %d\n", puente3 + 1);
  agregarPuentes(L, puente1, puente2, puente3);
}

void agregarPuentes(lista_t *L, int p1, int p2, int p3){
  int llegada1, llegada2, llegada3, flag = 0;
  nodo_lista_t *pAuxSalida = L->pCabeza;
  nodo_lista_t *pAuxLlegada = L->pCabeza;
  
  do{
  	pAuxSalida = L->pCabeza;
    pAuxLlegada = L->pCabeza;
    for(int i = 0; i < p1; i++){
      pAuxSalida = pAuxSalida->pSgte;
    }
    llegada1 = rand() % 22;
    for(int i = 0; i < llegada1; i++){
      pAuxLlegada = pAuxLlegada->pSgte;
    }
    if(pAuxLlegada->casilla.puntos != 0){
      flag++;
      pAuxSalida->pTunel = pAuxLlegada;
    }
  }while(flag != 1);
  flag = 0;
  
  do{
    pAuxSalida = L->pCabeza;
    pAuxLlegada = L->pCabeza;
    for(int i = 0; i < p2; i++){
      pAuxSalida = pAuxSalida->pSgte;
    }
    llegada2 = rand() % 22;
    if(llegada2 != llegada1){
      for(int i = 0; i < llegada2; i++){
        pAuxLlegada = pAuxLlegada->pSgte;
      }
      
      if(pAuxLlegada->casilla.puntos != 0){
        flag++;
        pAuxSalida->pTunel = pAuxLlegada;
      }
    }
  }while(flag != 1);
  flag = 0;
  
  do{
    pAuxSalida = L->pCabeza;
    pAuxLlegada = L->pCabeza;
    for(int i = 0; i < p3; i++){
      pAuxSalida = pAuxSalida->pSgte;
    }
    llegada3 = rand() % 22;
    if(llegada3 != llegada2 && llegada3 != llegada1){
      for(int i = 0; i < llegada3; i++){
        pAuxLlegada = pAuxLlegada->pSgte;
      }
      
      if(pAuxLlegada->casilla.puntos != 0){
        flag++;
        pAuxSalida->pTunel = pAuxLlegada;
      } 
    } 
  }while(flag != 1);
  printf("Llegada 1 en la casilla %d\n", llegada1+1);
  printf("Llegada 2 en la casilla %d\n", llegada2+1);
  printf("Llegada 3 en la casilla %d\n", llegada3+1);
}

void cambiarCasilla(lista_t *L){
  int nuevaC, nuevoI, flag = 0;
  nodo_lista_t *pCambiar = L->pCabeza;
  nodo_lista_t *pNuevaC = L->pCabeza;
  do{
    nuevaC = rand() % 22;
    while(pCambiar->casilla.cambio == NO){
      pCambiar = pCambiar->pSgte;
    }
    for(int i = 0; i < nuevaC; i++){
      pNuevaC = pNuevaC->pSgte;
    }
    if(pNuevaC->casilla.puntos > 0){
      pNuevaC->casilla.cambio = SI;
      pCambiar->casilla.puntos = pNuevaC->casilla.puntos;
      pCambiar->casilla.cambio = NO;
      flag++;
    }
    pCambiar = L->pCabeza;
    pNuevaC = L->pCabeza;
  }while(flag != 1);

  do{
    nuevoI = rand() % 22;
    while(pCambiar->casilla.inicio == NO){
      pCambiar = pCambiar->pSgte;
    }
    for(int i = 0; i < nuevoI; i++){
      pNuevaC = pNuevaC->pSgte;
    }
    if(pNuevaC->casilla.puntos > 0){
      pNuevaC->casilla.inicio = SI;
      pCambiar->casilla.puntos = pNuevaC->casilla.puntos;
      pCambiar->casilla.inicio = NO;
      flag++;
    }
    pCambiar = L->pCabeza;
    pNuevaC = L->pCabeza;
  }while(flag != 1);
}

void moverJugador(lista_t *L, int movimientos, int *puntaje, int *termino, int *cambiar){
  nodo_lista_t *pCasAct = L->pCabeza;
  int i = 0;
  while(pCasAct->casilla.jugador == NO){
    pCasAct = pCasAct->pSgte;
  }
  pCasAct->casilla.jugador = NO;
  while(pCasAct->casilla.fin != SI && i < movimientos){
    pCasAct = pCasAct->pSgte;
    i++;
  }
  if(pCasAct->casilla.tunel == SI){
    pCasAct = pCasAct->pTunel;
  }
  pCasAct->casilla.jugador = SI;
  if(pCasAct->casilla.fin == SI){
    *termino = SI;
  }
  if(pCasAct->casilla.cambio == SI){
  	*cambiar = SI;
  }
  *puntaje += pCasAct->casilla.puntos;
}

int juego(lista_t *L){
  int puntaje = 0, fin = NO, cambiar = NO, dado;
  do{
    printf("\nTira el dado\n");
    //system("Pause");
    printf("\n");
    dado = 1 + rand() % 7;
    printf("SACO %d\n", dado);
    //printf("%d\n", fin);
    //printf("%d\n", cambiar);
    moverJugador(L, dado, &puntaje, &fin, &cambiar);
    printf("========================================================================\n");
    imprimirTablero(L);
    printf("Puntaje actual: %d\n", puntaje);
  }while(fin == NO);
  if(cambiar == SI){
    cambiarCasilla(L);
  }
  printf("\nFin del juego\n");
  imprimirTablero(L);
  printf("\nTu puntaje fue: %d\n", puntaje);
  return puntaje;
}