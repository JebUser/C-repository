#ifndef TABLERO_H
#define TABLERO_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef enum { VACIA = 0, NO_VACIA = 1, SI = 1, NO = 0 } estado_e;


// Dato de la casilla
typedef struct casilla {
  int puntos;
  int inicio;
  int fin;
  int tunel;
  int cambio;
  int jugador;
} casilla_t;

// Nodo de cada casilla
typedef struct nodoLista {
  casilla_t casilla;
  struct nodoLista *pSgte;
  struct nodoLista *pTunel;
} nodo_lista_t;

// La lista/Tablero
typedef struct lista {
  nodo_lista_t *pCabeza;
} lista_t;


//prototipos
void imprimirTablero(lista_t *L);
void agregarTablero(lista_t *L);
void agregarPuentes(lista_t *L, int p1, int p2, int p3);
void cambiarCasilla(lista_t *L);
void moverJugador(lista_t *L, int movimientos, int *puntaje, int *termino, int *cambiar);
int juego(lista_t *L);
nodo_lista_t *crearNodo(int puntos, int inicial, int final, int cambio, int puente, int jugador);
casilla_t crearCasilla(int puntos, int inicial, int final, int cambio, int puente, int jugador);
lista_t *crearLista();
int eslistaVacia(lista_t *l);
#endif