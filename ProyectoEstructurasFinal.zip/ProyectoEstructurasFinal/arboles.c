#include "arboles.h"

nodo_arbol_t *crearNodoArbol(nodo_arbol_t *padre, int valor, int puntuacion){

    nodo_arbol_t *nodo = (nodo_arbol_t*)malloc(sizeof(nodo_arbol_t));
    nodo->padre = padre;
    nodo->valor = valor;
    nodo->puntuacion = puntuacion;
    nodo->izquierda = NULL;
    nodo->derecha = NULL;

    return nodo;
}
nodo_arbol_t *menorN(nodo_arbol_t *arbol){

    nodo_arbol_t *aux = arbol;

    while(aux->izquierda!=NULL){

        aux = aux->izquierda;
    }
    return aux;
}

nodo_arbol_t *mayorN(nodo_arbol_t *arbol){

    nodo_arbol_t *aux = arbol;

    while(aux->derecha!=NULL){

        aux = aux->derecha;
    }
    return aux;
}

void reemplazarArbol(nodo_arbol_t *arbol, nodo_arbol_t *Nodo2){

    if(arbol->padre!=NULL){

        if(arbol->valor == arbol->padre->izquierda->valor){
            
            arbol->padre->izquierda = Nodo2;
        }

        else if(arbol->valor == arbol->padre->derecha->valor){
            arbol->padre->derecha = Nodo2;
        }
    }
    if(Nodo2!=NULL){

        Nodo2->padre = arbol->padre;         
    }
}

void agregarNodoArbol(nodo_arbol_t *arbol, int valor, int puntuacion){
  nodo_arbol_t *actual, *anterior;
  int direccion=0;

  if(arbol!=NULL){
    actual = arbol;
    while(actual!= NULL){
      anterior = actual;
      if(puntuacion > actual->puntuacion){
        actual = actual ->derecha;
        direccion = 1; 
      }
      else{
        actual = actual ->izquierda;
        direccion = 0;
      }
    }
    actual = crearNodoArbol(anterior, valor, puntuacion);
    if(direccion == 1){
      anterior ->derecha = actual;
    }
    else{
      anterior->izquierda = actual;
    }
  }
}

void eliminarArbol(nodo_arbol_t *nodoeliminar){
  if(nodoeliminar->izquierda != NULL && nodoeliminar->derecha != NULL){
    nodo_arbol_t *menor = menorN(nodoeliminar->derecha);
    nodoeliminar->valor = menor->valor;
    eliminarArbol(menor);
  }
  else if(nodoeliminar->izquierda!=NULL){
    reemplazarArbol(nodoeliminar, nodoeliminar->izquierda);
    free(nodoeliminar);
  }
  else if(nodoeliminar->derecha !=NULL){  
    reemplazarArbol(nodoeliminar, nodoeliminar->derecha);
    free(nodoeliminar);
  }
  else{
    reemplazarArbol(nodoeliminar,NULL);
    free(nodoeliminar);
  }
}

void imprimirArbol(nodo_arbol_t *arbol,int valor){
  if(arbol==NULL){
    printf("\n");
  }
  else{
    imprimirArbol(arbol->izquierda,valor);
    if(arbol->valor == valor){
      eliminarArbol(arbol);
    }
    imprimirArbol(arbol->derecha,valor);
  }
}

void imprimito(nodo_arbol_t *arbol){
    if(arbol==NULL){
        printf("fin");
    }
    else{
        imprimito(arbol->izquierda);
        printf("%i\n", arbol->puntuacion);
        imprimito(arbol->derecha);
    }
}