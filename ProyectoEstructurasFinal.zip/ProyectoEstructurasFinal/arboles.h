#ifndef ARBOLES_H
#define ARBOLES_H

#include<stdio.h>
#include<stdlib.h>

typedef struct nodoArbol{

    int valor;
    int puntuacion;
    struct nodoArbol *padre;
    struct nodoArbol *izquierda;
    struct nodoArbol *derecha;

}nodo_arbol_t;

nodo_arbol_t *crearNodoArbol(nodo_arbol_t *padre, int valor, int putuacion;);
nodo_arbol_t *menorN(nodo_arbol_t *arbol);
nodo_arbol_t *mayorN(nodo_arbol_t *arbol);
void reemplazarArbol(nodo_arbol_t *arbol, nodo_arbol_t *nodo2);
void agregarNodoArbol(nodo_arbol_t *arbol, int valor, int puntuacion);
void eliminarArbol(nodo_arbol_t *nodoeliminar);
void imprimirArbol(nodo_arbol_t *arbol,int valor);
void imprimito(nodo_arbol_t *arbol);
#endif