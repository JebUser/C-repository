#include "colaJugadores.h"
#include "Tablero.h"

nodo_cola_t* crearNodoCola(){
	nodo_cola_t *nuevoNodo = (nodo_cola_t*)malloc(sizeof(nodo_cola_t));
	if (nuevoNodo == NULL){
		printf("No se pudo separar espacio\n");
	}
	else{
    fflush(stdin);
		printf("Ingrese el nombre del jugador:\n");
		fflush(stdin);
		fgets(nuevoNodo -> nombre, 20, stdin);
		fflush(stdin);
		printf("Ingrese el ID del jugador:\n");
		scanf("%d", &nuevoNodo -> id);
		
		nuevoNodo -> puntuacion = 0;
	}
	nuevoNodo -> pAnt = NULL;
	return nuevoNodo;
}

void agregarNodoCola(cola_t *cola){
  nodo_cola_t* nuevoNodo = crearNodoCola();
  if(cola -> inicioCola == NULL){
    cola -> inicioCola = nuevoNodo;
    cola -> finCola = nuevoNodo;
  }
  else{
    cola -> inicioCola -> pAnt = nuevoNodo;
    cola -> inicioCola = nuevoNodo;
  }
  printf("Jugador agregado\n");
}

cola_t *crearCola(){
  cola_t *nuevaCola = (cola_t*)malloc(sizeof(cola_t));
  nuevaCola -> inicioCola = NULL;
  nuevaCola -> finCola = NULL;
  return nuevaCola;
}

void quitarDeCola(cola_t *cola){
  if (cola -> finCola == NULL){
    printf("La cola esta vacia");
  }
  else{
    nodo_cola_t *pAux = cola -> finCola;
    cola -> finCola = cola -> finCola -> pAnt;
    //free(pAux);
  }
}

void imprimirCola(cola_t *cola){
  if(cola -> inicioCola == NULL){
	printf("La cola esta vacia");
  }
  else{
    nodo_cola_t *pAux = cola -> finCola;
    while(pAux != NULL){
    	printf("-------------\n");
    	printf("Nombre: %s", pAux -> nombre);
		printf("ID: %d\n", pAux -> id);
		printf("-------------\n");
		quitarDeCola(cola);
		pAux = cola -> finCola;
    }
  }
}