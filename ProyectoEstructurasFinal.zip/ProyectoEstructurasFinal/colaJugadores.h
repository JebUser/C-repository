#ifndef COLA_JUGADORES_H
#define COLA_JUGADORES_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
/*
typedef enum { 
  VACIA = 0, 
  NO_VACIA = 1
}estado_e;
*/
typedef struct nodoCola{
	char nombre[20];
	int puntuacion;
	int id;
	struct nodoCola *pAnt;
}nodo_cola_t;

typedef struct cola{
	nodo_cola_t *inicioCola;
	nodo_cola_t *finCola;
}cola_t;

nodo_cola_t* crearNodoCola();
void agregarNodoCola(cola_t *cola);
cola_t *crearCola();
void quitarDeCola(cola_t *cola);
void imprimirCola(cola_t *cola);

#endif