#include "Tablero.h"
#include "colaJugadores.h"
#include "arboles.h"
/*
Codigo elaborado por:
Juan Esteban Becerra
Laura Catalina Lozano
*/

void menuJuego(){
  cola_t *jugadores = crearCola();
  lista_t *Tablero = crearLista();
  nodo_arbol_t *menor;
  nodo_arbol_t *mayor;
  nodo_arbol_t *TablaPuntuaciones = (nodo_arbol_t*)calloc(1, sizeof(nodo_arbol_t));
  int sel, Njugadores = 0, puntos, elim, id1;
  do{
    printf("\nSeleccione opcion\n");
    printf("1. Encolar Jugadores\n");
    printf("2. Empezar Juego\n");
    printf("3. Ver minimo puntaje\n");
    printf("4. Ver maximo puntaje\n");
    printf("5. Eliminar un jugador por id\n");
    printf("6. Ver jugadores\n");
    printf("7. Salir\n");
    scanf("%d", &sel);
    switch(sel){
      case 1:
        printf("Indique cuantos jugadores a jugar\n");
        scanf("%d", &Njugadores);
        for(int i = 0; i < Njugadores; i++){
          agregarNodoCola(jugadores);
        }
        break;
      case 2:
        if(Njugadores > 0){
            printf("\nConvenciones\n\n");
            agregarTablero(Tablero);
            printf("\nTablero Inicial\n");
            imprimirTablero(Tablero);
            for(int j = 0; j < Njugadores; j++){
            	printf("Turno del jugador: %d\n", j+1);
            	puntos = juego(Tablero);
            	id1 = jugadores->finCola->id;
            	agregarNodoArbol(TablaPuntuaciones, id1, puntos);
				quitarDeCola(jugadores);
			}
        }
        else{
          printf("No se han agregado jugadores\n");
        }
        break;
      case 3:
      		menor = menorN(TablaPuntuaciones);
  			printf("%d", menor->puntuacion);
        break;
      case 4:
  			mayor = mayorN(TablaPuntuaciones);
  			printf("%d", mayor->puntuacion);
        break;
      case 5:
      		printf("Ingrese id a eliminar\n");
      		scanf("%d", &elim);
  			imprimirArbol(TablaPuntuaciones, elim);
  			printf("Se elimino el jugador con id %d", elim);
        break;
      case 6:
        imprimirCola(jugadores);
        break;
      case 7:
        printf("Saliendo\n");
        break;
      default:
        printf("Opcion no valida, ingrese otra\n");
    }
  }while(sel != 7);
}
int main(void) {
  menuJuego();
  return 0;
}