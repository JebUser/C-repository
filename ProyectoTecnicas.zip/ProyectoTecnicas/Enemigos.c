#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Enemigos.h"

//Funcion que imprime todos los datos del enemigo y su posicion en el bestiario
void imprimirEnemigo(enemigo mismo, int num){
	printf("=================================\n");
	printf("\nEnemigo %d", num+1);
	printf("\nNombre: %s\n", mismo.nombre);
	printf("\nTipo: %s\n", mismo.tipo);
	printf("\nPuntos de Vida: %d\n", mismo.puntosVida);
	printf("\nAtaque: %d\n", mismo.ataque);
	printf("\nDefensa: %d\n", mismo.defensa);
	//printf("\nVisto: %d\n", mismo.visto);
}