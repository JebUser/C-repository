#ifndef ENEMIGOS_H
#define ENEMIGOS_H
#include <stdio.h>
/*
 * @name: enemigo
 * @member:
 * - nombre Enemigo
 * - nombre tipo Enemigo
 * - int vida del Enemigo
 * - int ataque del Enemigo
 * - int defensa del Enemigo
 * - int bandera que define si el enemigo ha sido visto
 * @description: Estructura que contiene datos de cada enemigo
 */
typedef struct enemigo{
  char nombre [30];
  char tipo [15];
  int puntosVida;
  int ataque;
  int defensa;
  int visto;
}enemigo;

/*
 * @name: bestiario
 * @member:
 * - Bestiario de enemigos
 * @description: Estructura que contiene datos de cada enemigo
 */
typedef struct bestiario{
  enemigo Bestiario[50];
}Bestiario;

/*
 * @name: agregarItem
 * @params
 * - mismo enemigo
 * @description: imprime las estadisticas y datos del enemigo
*/
void imprimirEnemigo(enemigo mismo, int num);

#endif