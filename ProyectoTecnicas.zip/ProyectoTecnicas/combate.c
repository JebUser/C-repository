#include "combate.h"

void menuCombate(){
	printf("=================================\n");
	printf("Que acción deseas relizar:\n ");
	printf("1. Atacar\n");
	printf("2. Magia\n");
	printf("3. Retirarse\n");
	printf("4. Inventario");
	printf("=================================\n");
}

void imprimirEnemigoC(enemigo mismo, int i){
	printf("=================================\n");
	printf("\nEnemigo %d\n", i);
	printf("\nNombre: %s\n", mismo.nombre);
	printf("\nPuntos de Vida: %d\n", mismo.puntosVida);
	printf("\nAtaque: %d\n", mismo.ataque);
	printf("\nDefensa: %d\n", mismo.defensa);
}

void combate(equipo *team, Bestiario enemigos, int mundoAct){
	srand(time(0));
	int Nrivales = 1 + rand() % 5;
	enemigo rivales[Nrivales];
	int rival;
	int i;
	if(mundoAct == 1){
		for(i = 0; i < Nrivales; i++){
			rival = rand() % 8;
			rivales[i] = enemigos.Bestiario[rival];
		}
	}
	if(mundoAct == 2){
		for(i = 0; i < Nrivales; i++){
			rival = 10 + rand() % 8;
			rivales[i] = enemigos.Bestiario[rival];
		}
	}
	if(mundoAct == 3){
		for(i = 0; i < Nrivales; i++){
			rival = 20 + rand() % 8;
			rivales[i] = enemigos.Bestiario[rival];
			}	
	}
	if(mundoAct == 4){
		for(i = 0; i < Nrivales; i++){
			rival = 30 + rand() % 8;
			rivales[i] = enemigos.Bestiario[rival];
		}
	}
	if(mundoAct == 5){
		for(i = 0; i < Nrivales; i++){
			rival = 40 + rand() % 8;
			rivales[i] = enemigos.Bestiario[rival];
		}
	}
	printf("\nHAN APARECIDO ESTOS ENEMIGOS!\n\n");
	for(i = 0; i < Nrivales; i++){
		imprimirEnemigoC(rivales[i]);
	}
	int escape, selR, selP, atqRivales, turnos = 0, turnoJ1 = 0, turnoJ2 = 0, turnoJ3 = 0, turnoJ4 = 0;
	do{
		turnos = 0;
		turnoJ1 = 0;
		turnoJ2 = 0;
		turnoJ3 = 0; 
		turnoJ4 = 0;
		while(turnos < 4){
			if(team->equipo[1].vidaAct <= 0){
				team->equipo[1].vidaAct = 0;
				turnoJ1 = 1;
			}
			if(team->equipo[2].vidaAct <= 0){
				team->equipo[2].vidaAct = 0;
				turnoJ2 = 1;
			}
			if(team->equipo[3].vidaAct <= 0){
				team->equipo[3].idaAct = 0;
				turnoJ3 = 1;
			}
			if(team->equipo[4].vidaAct <= 0){
				team->equipo[4].vidaAct = 0;
				turnoJ4 = 1;
			}
			menuCombate();
			scanf("%d", sel);
			switch (sel){
				case 1:
					printf("Elige rival a atacar:\n ");
					scanf("%d", selR);
					if(selR < Nrivales && selR > 0){
						printf("Elige personaje para atacar:\n ");
						scanf("%d", selP);
						if((selP == 1 && turnoJ1 = 0) || (selP == 2 && turnoJ2 = 0) || (selP == 3 && turnoJ3 = 0) || (selP == 4 &&turnoJ4 = 0){
							if(selP < 5 && selP > 0){
								if(selP == 1){turnoJ1++;}
								else if(selP == 2){turnoJ2++;}
								else if(selP == 3){turnoJ3++;}
								else {turnoJ4++;}
								&rivales[selR].puntosVida -= (equipo[selP].ataque *(0.75))-(rivales[selR].defensa * (0.05));
								turnos++;
							}
							else{
								printf("Seleccion erronea\n");
							}
						}
						else{
							printf("Jugador ya seleccionado previamente o deshabilitado\n");
						}
					}
					else{
						printf("Seleccion erronea\n");
					}
				break;
				
				case 2:
					printf("Elige rival a atacar:\n ");
					scanf("%d", selR);
					if(selR < Nrivales && selR > 0 && turnoJ1 = 0 && turnoJ2 = 0 && turnoJ3 = 0 && turnoJ4 = 0){
						printf("Elige personaje para atacar:\n ");
						scanf("%d", selP);
						if((selP == 1 && turnoJ1 = 0) || (selP == 2 && turnoJ2 = 0) || (selP == 3 && turnoJ3 = 0) || (selP == 4 &&turnoJ4 = 0){
							if(selP < 5 && selP > 0){
								&rivales[selR].defensa -= (equipo[selP].ataque *(0.09));
								turnos++;
							}
							else{
								printf("Seleccion erronea\n");
							}
						}
						else{
							printf("Jugador ya seleccionado previamente o deshabilitado\n");
						}
					}
					else{
						printf("Seleccion erronea\n");
					}			
				break;
				case 3:
					escape = rand() % 10;
					if(escape > 4){
						printf("No lograste escapar\n");
						turnos++;
					}
					else{
						printf("Escapde exitoso!\n");
					}
				break;
				default:
			}
		}
		
		
		for(int i = 0; i < Nrivales){
			atqRivales = rand  % 4;
			if(rivales[i].puntosVida > 0){
				printf("\nEl rival %s ataco a %s\n", rivales[i].nombre, team->equipo[atqRivales].nombre);
				team->equipo[atqRivales].vidaAct -= (rivales[i].ataque *(0.55)) - (team->equipo[atqRivales].defensa*(0.05));
			}
		}
	}while(escape < 5);
	
}