#ifndef COMBATE_H
#define COMBATE_H
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "personaje.h"
#include "enemigos.h"

typedef enum{
	VIVO = 1,
	MUERTO = 0,
}estado_vida;

void imprimirEnemigoC(enemigo mismo);
void combate(equipo *team, Bestiario enemigos, int mundoAct);
void menuCombate();
#endif