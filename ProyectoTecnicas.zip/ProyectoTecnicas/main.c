#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Enemigos.h"
#include "personaje.h"
#include "combate.h"
#define SIZE 300

typedef enum{
	VISTO = 1,
	NO_VISTO = 0
}estado;

int main() {
	//Crea el bestiario y lo llena
	Bestiario Libro;
	FILE * archivoM = fopen( "enemigos.txt", "r" );
    char buffer[ SIZE ];
    int entrada = 0;
    int subEntrada = 0;
    while( fgets( buffer, SIZE, archivoM ) != NULL ){
    	char * token = strtok( buffer, "," );
    	subEntrada = 0;
    	// Bucle que tokeniza cada linea y cargar los pokemons
    	while( token != NULL ){
    		if( subEntrada == 0 ) strcpy( Libro.Bestiario[ entrada ].nombre, token );
    		else if( subEntrada == 1 ) strcpy( Libro.Bestiario[ entrada ].tipo, token );
			else if( subEntrada == 2 ) Libro.Bestiario[ entrada ].puntosVida = atoi( token );
			else if( subEntrada == 3 ) Libro.Bestiario[ entrada ].ataque = atoi( token );
			else Libro.Bestiario[ entrada ].defensa = atoi( token );
	    	token = strtok( NULL, "," );
	    	subEntrada++;
    	}
    	Libro.Bestiario[entrada].visto = NO_VISTO;
    	entrada++;
	}
    fclose( archivoM );
    
	//Crea el arreglo de todos los items del juego
	objetos Items;
	FILE * archivoI = fopen( "item.txt", "r" );
    buffer[ SIZE ];
    entrada = 0;
    while( fgets( buffer, SIZE, archivoI ) != NULL ){
    	char * token = strtok( buffer, "," );
    	subEntrada = 0;
    	// Bucle que tokeniza cada linea y cargar los pokemons
    	while( token != NULL ){
    		if( subEntrada == 0 ) strcpy( Items.objetos[ entrada ].nombre, token );
    		else if( subEntrada == 1 ) strcpy( Items.objetos[ entrada ].tipo, token );
			else if( subEntrada == 2 ) Items.objetos[ entrada ].vida = atoi( token );
			else if( subEntrada == 3 ) Items.objetos[ entrada ].atq = atoi( token );
			else Items.objetos[ entrada ].def = atoi( token );
	    	token = strtok( NULL, "," );
	    	subEntrada++;
    	}
    	entrada++;
	}
    fclose( archivoI );
    
    //Crea el arreglo de los personajes a elegir del juego
	selector SelectorP;
	FILE * archivoP = fopen( "personajes.txt", "r" );
    buffer[ SIZE ];
    entrada = 0;
    while( fgets( buffer, SIZE, archivoP ) != NULL ){
    	char * token = strtok( buffer, "," );
    	subEntrada = 0;
    	// Bucle que tokeniza cada linea y cargar los pokemons
    	while( token != NULL ){
    		if( subEntrada == 0 ) strcpy( SelectorP.selPersonaje[ entrada ].nombre, token );
    		else if( subEntrada == 1 ) strcpy( SelectorP.selPersonaje[ entrada ].clase, token );
			else if( subEntrada == 2 ) SelectorP.selPersonaje[ entrada ].vidaMax = atoi( token );
			else if( subEntrada == 3 ) SelectorP.selPersonaje[ entrada ].ataque = atoi( token );
			else SelectorP.selPersonaje[ entrada ].defensa = atoi( token );
	    	token = strtok( NULL, "," );
	    	subEntrada++;
    	}
    	agregarItem(&SelectorP.selPersonaje[ entrada ], Items.objetos[15]);
    	entrada++;
	}
    fclose( archivoP );    
    
    //Imprime los enemigos dependiendo de si han sido vistos o no
    for(int i = 0; i < 50; i++){
    	if(Libro.Bestiario[i].visto == NO_VISTO){
			imprimirEnemigo(Libro.Bestiario[i], i);
		}
    	else {
    		printf("=================================\n");
    		printf("%d. Enemigo no encontrado\n", i+1);	
		}
	}
	system("pause");
	system("cls");
	
	
	//Crea el arreglo del equipo del jugador
	printf("Selecciona tu equipo:\n");
	equipo Team;
	int team[4];
	int sel;
	for(int j = 0; j < 10; j++){
		imprimirPersonaje(SelectorP.selPersonaje[j]);
	}
	int i = 0;
	do{		
		printf("Seleccione: ");
		scanf("%d", &sel);	
		if(team[0] != sel && team[1] != sel && team[2] != sel && team[3] != sel){
			//Asigna al equipo el personaje del arreglo seleccionado
			Team.equipo[i] = SelectorP.selPersonaje[sel-1];
			team[i] = sel;
			printf("Elegiste a %s!\n", SelectorP.selPersonaje[sel-1].nombre);
			i++;
		}
		else{
			printf("Ya seleccionaste a ese personaje\n\a");
		}
						
	}while(i < 4);
	
	//Imprime el equipo del jugador
	for(int i = 0; i < 4; i++){
		imprimirPersonaje(Team.equipo[i]);
	}
	
	system("pause");
	system("cls");
	
	//Imprime todos los objetos del juego
	for(int i = 0; i < 15; i++){
		imprimirItem(Items.objetos[i]);
	}
	
	system("pause");
	system("cls");
	
	combate(&Team, Libro, 3);
	
	return 0;
}