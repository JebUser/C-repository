//Imports
#include <stdlib.h>
#include <string.h>
#include "personaje.h"

/*
 * @name: personaje
 * @member:
 * - bestiario pokemon:
 * @description: Estructura que contiene la lista de pokemons
 */

//Funcion que asigna el item al personaje
void agregarItem(personaje *mismo, item Obj){
	mismo->equipamiento = Obj;
	mismo->ataque = mismo->ataque + Obj.atq;
	mismo->vidaMax = mismo->vidaMax + Obj.vida;
	mismo->defensa += mismo->defensa + Obj.def;
}

//Funcion que imprime las estadisticas del personaje
void imprimirPersonaje(personaje mismo){
	printf("=================================\n");
	printf("\nNombre: %s\n", mismo.nombre);
	printf("\nClase: %s\n", mismo.clase);
	printf("\nPuntos de Vida: %d\n", mismo.vidaMax);
	printf("\nAtaque: %d\n", mismo.ataque);
	printf("\nDefensa: %d\n", mismo.defensa);
	printf("\nItem equipado: %s\n", mismo.equipamiento.nombre);
}

//Funcion que imprime las estadisticas del item
void imprimirItem(item mismo){
	printf("=================================\n");
	printf("\nNombre: %s\n", mismo.nombre);
	printf("\nTipo: %s\n", mismo.tipo);
	printf("\nVida Otorgada: %d\n", mismo.vida);
	printf("\nAtaque: %d\n", mismo.atq);
	printf("\nDefensa: %d\n", mismo.def);
}