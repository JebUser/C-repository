//Imports
#ifndef PERSONAJE_H
#define PERSONAJE_H
#include <stdio.h>
 /* Structs */

/*
 * @name: item
 * @member:
 * - nombre Item
 * - nombre tipo Item
 * - int vida del Item
 * - int ataque del Item
 * - int defensa del Item
 * @description: Estructura que contiene datos de cada item
 */
 
typedef struct item{
	char nombre[30];
	char tipo[30];
	int vida;
	int atq;
	int def;
}item;

/*
 * @name: personaje
 * @member:
 * - nombre Personaje
 * - nombre Clase Personaje
 * - int vida Maxima del Personaje
 * - int vida Actual del Personaje
 * - int ataque del Personaje
 * - int defensa del Personaje
 * - item Item que lleva el Personaje
 * @description: Estructura que contiene las caracteristicas de un personaje
 */

typedef struct personaje{
	char nombre[30];
	char clase[20];
	item equipamiento;
	int vidaMax;
	int vidaAct;
	int ataque;
	int defensa;
}personaje;

/*
 * @name: selector
 * @member:
 * - Selector de Personajes
 * @description: Estructura que contiene el arreglo de todos los personajes del juego a elegir
 */

typedef struct seleccion{
	personaje selPersonaje[10];
}selector;
/*
 * @name: equipo
 * @member:
 * - Equipo de personajes
 * @description: Estructura que contiene el arreglo de personajes del equipo seleccionado por el jugador
 */

typedef struct equipo{
	personaje equipo[4];
}equipo;

/*
 * @name: objetos
 * @member:
 * - Lista de objetos
 * @description: Estructura que contiene el arreglo de todos los objetos y consumibles del juego
 */

typedef struct objetos{
	item objetos[16];
}objetos;

/*
 * @name: agregarItem
 * @params
 * - mismo personaje
 * - Objeto item
 * @description: agrega a la direccion de memoria de un personaje el item sumandole al personaje las estadisticas del objeto
*/
void agregarItem(personaje *mismo, item Obj);
/*
 * @name: imprimirPokemon
 * @params
 * - mismo personaje
 * @description: imprime los datos de un personaje
 */
void imprimirPersonaje(personaje mismo);
/*
 * @name: imprimirItem
 * @params
 * - mismo item
 * @description: imprime las estadisticas del item
*/
void imprimirItem(item mismo);

#endif