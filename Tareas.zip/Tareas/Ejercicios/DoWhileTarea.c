#include <stdio.h>
int conteo = 0;
float acumulado = 0;
float promedio = 0;
float nota;
int main(){
    do{
        scanf("%f", &nota);
        if(nota !=-1 && nota<=5 && nota>=0){
          conteo +=1;
          acumulado += nota;  
        }
        
    }
    while (nota != -1);
    promedio = acumulado/conteo;
    printf("Se conto %d datos\n", conteo);
    printf("El promedio es: %f", promedio);
    return 0;
}