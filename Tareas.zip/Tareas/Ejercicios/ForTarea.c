#include <stdio.h>

void a(){
    int num1 = 1;

    for(/*definir variable*/; num1 <= 6; num1++){
        printf( "%d ", num1 );
    }
    printf("%d", num1);
    return;
}

void b(){
    int num2 = 1;
    int i = 3;

    for(/*definir variable*/; num2 <= 4; num2++, i+=5){
        printf( "%d ", i );
    }
    printf("%d", i);
    return;
}

void c(){
    int num3 = 1;
    int j = 20;

    for(; num3 <= 5; num3++, j-=6){
        printf("%d ", j);
    }
    printf("%d ", j);
    return;
}
int main(){
    a();
    printf("\n");
    b();
    printf("\n");
    c();
    return 0;
}