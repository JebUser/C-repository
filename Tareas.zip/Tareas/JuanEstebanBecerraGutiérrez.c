#include <stdio.h>
#include <stdlib.h>

//Autor del código: Juan Esteban Becerra Gutiérrez

void taller(void);
void imprimirTriangulo(int n);
void imprimirTrianguloRecursivo(int n, int n2, int cont);
int multiplicarRecursivo(int a, int b, int r);

void imprimirTrianguloRecursivo(int n, int n2, int cont){
    if(n > n2){
        return;
    }
    else{
        if(cont < n){
            printf("+");
            return imprimirTrianguloRecursivo(n, n2, cont+1);
        }
        else{
            printf("\n");
            return imprimirTrianguloRecursivo(n+1, n2, 0);
        }
        
    }
}

void imprimirTriangulo(int n){
    for(int i=0; i < n; i++){
        for(int j = 0; j <= i; j++){
            printf("+");
        }
        printf("\n");
    }

}

int multiplicarRecursivo(int a, int b, int r){
    if(b == 0){
        return 0;
    }
    else{
        r += a;
        if(b-1 == 0){
            return r;
        }
        return multiplicarRecursivo(a, b-1, r);
    }
    
}

void taller(){
    int alt, num, op;
    printf("TALLER RECURSION\n");
    printf("PUNTO_1\nIngrese altura, use enteros: ");
    scanf("%d", &alt);
    printf("Escalera iterativa:\n");
    imprimirTriangulo(alt);
    printf("Escalera recursiva\n");
    imprimirTrianguloRecursivo(1, alt, 0);
    printf("PUNTO_2\nMultiplicar Recursivo, use enteros.\nIngrese numero: ");
    scanf("%d", &num);
    printf("Ingrese multiplicador: ");
    scanf("%d", &op);
    printf("El resultado de la multiplicacion es: %d", multiplicarRecursivo(num, op, 0));
    return;   
}

int main(){
    taller();
    return 0;
}