#include <stdio.h>
#include <math.h>
//Taller hecho por Juan Esteban Becerra
//Prototipos
int menu(void);
int sumarMults3(int nI, int nS);
int maximoDivisor(int n1, int n2);
int maxArreglo(int max, int maxN); 
int cicloFibonacci(int c, int num1, int num2);
int verificarIdentica(int f, int c, int pv);

//Punto 2
int sumarMults3(int nI, int nS){ // Usa recursion directa de caracter lineal con recursividad no final
    if(nS == nI){
        if(nS % 3 == 0){
            return nS;
        }               //Lo que retorna al final no es su llamado a si mismo, sino un numero.
        else{
            return 0;
        }
    }
    else if(nS % 3 == 0){
        return nS + sumarMults3(nI, nS-1); //Solo se llama a si misma una vez
    }
    else{
        return sumarMults3(nI, nS-1);
    }
}
//Punto 4
int maximoDivisor(int n1, int n2){
    int residuo = n1 % n2;
    if(residuo == 0){
        return n2;
    }
    else{
        return maximoDivisor(n2, residuo);
    }
    return 0;
}
//Punto 3
int lista[10] = {155,14,55,6,8,9,1,2,33,46};
int maxArreglo(int max, int maxN){
    if(maxN < 9){
        if(lista[max] >= lista[maxN]){
            return maxArreglo(max, maxN+1);
        }
        else{
            return maxArreglo(maxN, maxN+1);
        }
    }   
    else{
        
        if(lista[max] > lista[maxN]){
            return lista[max];
        }
        else{
            return lista[maxN];
        }
    }
}
//Punto 5
int cicloFibonacci(int c, int num1, int num2){
    if(c != 0){
        int n1 = num1;
        int n2 = num2;
        int sigTerm = n1 + n2;
        if(c != 1){
            printf("%d, ", sigTerm);
        }
        else{
            printf("%d", sigTerm);
        }
        n1 = n2;
        n2 = sigTerm;
        sigTerm = n1 + n2;
        return cicloFibonacci(c-1, n1, n2);
    }
    else{
        return 0;
    }
}

int matriz[3][3] = {{1, 0, 0},
                    {0, 1, 0}, 
                    {0, 0, 1}};
int verificarIdentica(int f, int c, int pv){
    if(f < 3){
        if(c < 3){
            if(pv == 0){
                if(matriz[f][c] == 1){
                   return verificarIdentica(f, c+1, 4); 
                }
                else{
                    return 0;
                }
            }
            else{
                if(matriz[f][c] == 0){
                    return verificarIdentica(f, c+1, pv-1); 
                }
                else{
                    return 0;
                }
            }
            
        }
        else{
            return verificarIdentica(f+1, 0, pv-1);
        }
    }
    else{
        return 1;
    }
}

//Menu
int menu(void){
    int sel;
    int nI, nS, num1, num2, num3;
    printf("\nTALLER RECURSION\n");
    printf("1. Ejercicio 1\n");
    printf("2. Ejercicio 2\n");
    printf("3. Ejercicio 3\n");
    printf("4. Ejercicio 4\n");
    printf("5. Ejercicio 5\n");
    printf("6. Salir\n");
    printf("Selecione opcion: ");
    scanf("%d", &sel);
    if(sel != 6){
        if(sel == 1){
            printf("Elija rango\n");
            printf("Limite inferior: \n");
            scanf("%d", &nI);
            printf("Limite superior: \n");
            scanf("%d", &nS);
            printf("La suma de los multimos de 3 es %d\n", sumarMults3(nI, nS));
        }
        if(sel == 2){
            printf("Elija numeros\n");
            scanf("%d\n", &num1);
            scanf("%d", &num2);
            if(num1 > num2){
                printf("El maximo comun divisor es: %d", maximoDivisor(num1, num2));
            }
            else{
                printf("El maximo comun divisor es: %d", maximoDivisor(num2, num1));  
            }

        }
        if(sel == 3){
            printf("El numero maximo de la lista es: %d", maxArreglo(0, 0));
        }
        if(sel == 4){
            int v1 = 0;
            int v2 = 1;
            printf("Introduzca numero hasta donde se imprimia el fibonacci: ");
            scanf("%d", &num3);
            cicloFibonacci(num3-2, v1, v2);
            if(num3 != 1){
            printf("La sucesion fibonacci de %d es: %d, %d, ", num3, v1, v2);
            cicloFibonacci(num3-2, v1, v2);
            }
            else{
                printf("La sucesion fibacci de %d es: %d", num3, v2);
            }
            
            
        }
        if(sel == 5){
            int esIdentica = verificarIdentica(0, 0, 0);
            if(esIdentica == 1){
                printf("La matriz es identica");
            }
            else{
                printf("La matriz no es identica");
            }

        }
        return menu();
    }
    else{
        return 0;
    }
}

int main(){
    menu();
    return 0;
}