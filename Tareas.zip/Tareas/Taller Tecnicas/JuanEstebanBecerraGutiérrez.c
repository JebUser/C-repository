#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/*
Taller realizado por
Juan Esteban Becerra Gutiérrez
*/
//==========================================
//Punto1
int esPar(int number);
int sumPares;

void imprimirNumerosAl50(){
    int n;
    srand(time(0));
    for(int i = 1; i <= 50; i++){
        n = rand() % 100;
        printf("%d ", n);
        if(esPar(n)==1){
            sumPares+=n;
        }
    }
    printf("\nLa suma de los pares es: %d\n", sumPares);
    return;
}

int esPar(int number){ //Funcion que retorna 1 si es primo, y 0 si no
    if(number % 2 == 0){
        return 1;
    }
    else{
        return 0;
    }
}
//================================================
//Punto2
int ganadorJugador, ganadorMaquina, opMach, opMachP, opJP, especial, espJ, espM;
int empElemt = 0;
int eleccionMaquina(int opM);
int opcionMaquinaPoder(int opMP);


int eleccionMaquina(int opM){ //Imprime la elección de la maquina
    if(opM == 0){
        printf("La maquina eligio Piedra\n");
    }
    else if(opM == 1){
        printf("La maquina eligio Papel\n");
    }
    else if(opM == 2){
        printf("La maquina eligio Tijera\n");
    }
    return 0;
}
int eleccionMaquinaPoder(int opMP){ //Imprime la eleccion del elemento de la maquina
    if(opMP == 0){
        printf("La maquina eligio Fuego\n");
    }
    else if(opMP == 1){
        printf("La maquina eligio Hierba\n");
    }
    else if(opMP == 2){
        printf("La maquina eligio Agua\n");
    }
    return 0;
}
void juegoPoderes(){ //Procedimiento que hace la fase del juego elemental
    empElemt = 0;
    opMachP = rand()%3;
    do{
        printf("Seleccione elemento:\n");
        printf("1. Fuego\n");
        printf("2. Hierba\n");
        printf("3. Agua\n");
        scanf("%d", &opJP);
        if(opJP > 3 || opJP < 1){
            printf("Opcion no valida, digite otra\n");
        }
    }
    while(opJP > 3 || opJP < 1);
    eleccionMaquinaPoder(opMachP);

    //Puntos para el jugador
    if(opJP == 1 && opMachP == 1){
        ganadorJugador++;
        printf("Punto para el jugador\n");
    }
    else if(opJP == 2 && opMachP == 2){
        ganadorJugador+=1;
        printf("Punto para el jugador\n");
    }
    else if(opJP == 3 && opMachP == 0){
        ganadorJugador+=1;
        printf("Punto para el jugador\n");
    }
    //Puntos para la maquina
    else if(opJP == 1 && opMachP == 2){
        ganadorMaquina++;
        printf("Punto para la computadora\n");
    }
    else if(opJP == 2 && opMachP == 0){
        ganadorMaquina++;
        printf("Punto para la computadora\n");
    }
    else if(opJP == 3 && opMachP == 1){
        ganadorMaquina++;
        printf("Punto para la computadora\n");
    }
    else{
        printf("Empate elemental\nSe decidira la victoria por la reglas normales\n");
        empElemt = 1;
    }
}

void juego(){
    do{
        srand(time(0));
        opMach = rand() % 3; //Asigna la eleccion de la mano
        especial = rand()% 10; //Asigna la probabilidad del evento elemental
        int opJ;
        do{
            printf("\nPIEDRA, PAPEL O TIJERA\n");
            printf("Seleccione movimiento:\n");
            printf("1. Piedra\n");
            printf("2. Papel\n");
            printf("3. Tijera\n");
            scanf("%d", &opJ);
            if(opJ > 3 || opJ < 1){
                printf("Opcion no valida, digite otra\n");
            }
        }
        while(opJ > 3 || opJ < 1);
        eleccionMaquina(opMach);
        if(especial > 4){ //40% de probabilidad de que ocurra el evento
            printf("AHORA LA MANO SE DECIDE POR LOS ELEMENTOS\n");
            espJ = rand()%20;
            espM = rand()%20;
            if(espJ > 7 && espM > 7){ //La probabilidad de que ambos tomen un elemento especial, que es baja para que no ocurra seguido
                juegoPoderes();
                if(empElemt == 1){
                    especial = 0;
                }
            }
            else{
                printf("Solo un jugador obtuvo una ventaja elemental, se decidira la victoria por las reglas normales\n");
                especial = 0;
            }
        }
        if(especial < 5){
            //Puntos para el jugador
            if(opJ == 1 && opMach == 2){
                ganadorJugador++;
                printf("Punto para el jugador\n");
            }
            else if(opJ == 2 && opMach == 0){
                ganadorJugador+=1;
                printf("Punto para el jugador\n");
            }
            else if(opJ == 3 && opMach == 1){
                ganadorJugador+=1;
                printf("Punto para el jugador\n");
            }
            //Puntos para la maquina
            else if(opJ == 1 && opMach == 1){
                ganadorMaquina++;
                printf("Punto para la computadora\n");
            }
            else if(opJ == 2 && opMach == 2){
                ganadorMaquina++;
                printf("Punto para la computadora\n");
            }
            else if(opJ == 3 && opMach == 0){
                ganadorMaquina++;
                printf("Punto para la computadora\n");
            }
            else{
                printf("Empate\n");
            }
        }
        
    }
    while(ganadorJugador != 2 && ganadorMaquina != 2);
    if(ganadorJugador == 2){
        printf("Gano el jugador, felicidades");
    }
    else{
        printf("Gano la maquina, suerte para la proxima");
    }
    return;
    }


//=================================================
int main(){
    imprimirNumerosAl50();
    juego();
    return 0;
}