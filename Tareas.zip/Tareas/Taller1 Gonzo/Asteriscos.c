//Programa que imprime asteriscos hasta que el user digite un # negativo o 0
#include <stdio.h>
int cantidadAsteriscos(int cant);

int cantidadAsteriscos(int cant){ //Funcion que imprime los asteriscos
    int j = 0;
    while(j < 2){
        printf("%d ", cant);
        for(int i = 0; i < cant; i++){
            printf("* ");
        }
        printf("%d\n", cant);
        j++;
    }
    return 0;
}
void imprimirAsteriscos(){ //Funcion que hace que imprima los casos hasta un valor menor o igual 0
    int num;
    do{
        printf("Ingrese cantidad de asteriscos: ");
        scanf("%d", &num);
        if(num < 16){
            if(num > 0){
                cantidadAsteriscos(num);
            }
        }
        else{
            printf("Numero grande, ingrese otro\n");
        }
    }
    while(num > 0);
    return;
}

int main(){
    imprimirAsteriscos();
    return 0;
}