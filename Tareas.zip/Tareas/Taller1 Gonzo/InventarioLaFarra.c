
#include<stdio.h>
int papa, tomate, cebolla, naranja, mango;
int tPapa, tTomate, tCebolla, tNaranja, tMango;
int tB3, tB4;
void camionA(){ //Para preguntar por el camion A
    printf("Ingrese los kilos de papa: ");
    scanf("%d", &papa);
    return;
}
void camionB2(){ //Para preguntar sobre el camion B de 2 productos
    printf("Ingrese los kilos de papa: ");
    scanf("%d", &papa);
    printf("Ingrese los kilos de cebolla: ");
    scanf("%d", &cebolla);
    tCebolla+=cebolla;
    return;
}

void camionB3(){ //Para preguntar sobre el camion B de 3 productos
    printf("Ingrese los kilos de tomate: ");
    scanf("%d", &tomate);
    tTomate+=tomate;
    printf("Ingrese los kilos de cebolla: ");
    scanf("%d", &cebolla);
    tCebolla+=cebolla;
    printf("Ingrese los kilos de naranja: ");
    scanf("%d", &naranja);
    return;
}

void camionB4(){ //Para preguntar sobre el camion B de 4 productos
    printf("Ingrese los kilos de tomate: ");
    scanf("%d", &tomate);
    tTomate+=tomate;
    printf("Ingrese los kilos de cebolla: ");
    scanf("%d", &cebolla);
    tCebolla+=cebolla;
    printf("Ingrese los kilos de naranja: ");
    scanf("%d", &naranja);
    printf("Ingrese los kilos de mango: ");
    scanf("%d", &mango);
    tMango+=mango;
    return;
}

void seleccionB(){ //Para preguntar cuantos productos trae el camion B
    int prods;
    printf("Cuantos productos: ");
    scanf("%d", &prods);
    switch (prods)
    {
    case 2:
        camionB2();
        break;
    case 3:
        camionB3();
        tB3++;
        break;
    case 4:
        camionB4();
        tB4++;
        break;
    default:
        printf("Numero no valido");
        break;
    return;
    }
}

void contarProds(){
    int camiones, tA, tB;
    printf("Cuantos camiones llegaron: ");
    scanf("%d", &camiones);
    printf("Cuantos de tipo A: ");
    scanf("%d", &tA);
    printf("Cuantos de tipo B: ");
    scanf("%d", &tB);
    if(tA+tB == camiones){
        if(tA > 0){
            printf("Camion A:\n");
            for(int i = 0; i < tA; i++){ //Abre el contador de camiones A y sus prods
                camionA();
            }
        }
        if(tB > 0){
            printf("Camion B:\n");
            for(int j = 0; j < tB; j++){ // Abre el contador de camiones B y saber cuantos prods
                seleccionB();
            }
        }
    }
    else {
        printf("Cantidad de camiones no valida");
    }
    printf("\nResumen del trabajo:\n");
    printf("Llegaron %d camiones tipo A\n", tA);
    printf("Llegaron %d camiones de 3 productos y %d de 4 productos\n", tB3, tB4);
    printf("Llegaron %d kilos de cebolla\n", tCebolla);
    printf("Llegaron %d kilos de tomate\n", tTomate);
    printf("Llegaron %d kilos de mango\n", tMango);
    return;
}

int main(){
    contarProds();
    return 0;
}