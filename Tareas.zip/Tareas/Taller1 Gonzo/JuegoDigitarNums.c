//Juego en que el user digital # del 50 al 80
#include <stdio.h>
int contadoresNums(int cant);
int cont71 = 0;
void contador71(){ //Funcion para contar el 71
   
    if(cont71 == 0){
        printf("\nFelicitaciones\n");
        cont71++;
    }
    else if(cont71 == 1){
        printf("\nManana le doy un premio\n");
        cont71++;
    }
    else if(cont71 == 2){
        printf("\nEsta muy sus\n");
        cont71++;
    }
    else{
        printf("Sigue estando muy sus");
    }
    return;
}

int contadoresNums(int cant){ // Funcion que cuenta los numeros
    int i = 0;
    int n = 0;
    int contador = 0;
    int contador5060 = 0;
    int acumulado = 0;
    float promedio = 0;
    do{
        printf("Ingrese numero entre 50 y 80: ");
        scanf("%d", &n);
        if(n > 49 && n <81){
            if(n == 71){
                contador71();
            }
            else if(n>49 && n<61){ //Cuenta # entre el 49 y 61
                contador5060++;
                contador++;
                acumulado+=n;
            }
            else{
                acumulado+=n;
                contador++;
            }
            i++;
        }
        else{
            printf("\nNumero no valido, ingrese otro\n");
        }
    }
    while(i < cant);
    promedio = acumulado/contador;
    printf("Se contaron %d numeros.\n", contador);
    printf("El promedio de los numeros es: %f\n", promedio);
    printf("Se contaron %d numeros entre el 50 y 60.\n", contador5060);
    return 0;
}
void juego(){
    int nums;
    printf("Ingrese cantidad de numeros a ingresar: ");
    scanf("%d", &nums);
    contadoresNums(nums);
    return;
}

int main(){
    juego();
    return 0;
}