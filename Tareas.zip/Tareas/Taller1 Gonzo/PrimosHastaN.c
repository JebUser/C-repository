#include <stdio.h>
#include <stdlib.h>

int sacarPrimo(int n);
int sumarSiPrimo(int n1);

int sacarPrimo(int n){
    int esprimo = 1;
    for(int j = 2; j < n-1; j++){
        if(n%j == 0){
            esprimo = 0;
        }
    }
    if(esprimo == 1){
        return 1;
    }
    else{
        return 0;
    }
}

int sumarSiPrimo(int n1){ 
    int numEntero = n1;
    float sumDigit = 0;
    float extNum = 0;
    while(numEntero != 0) {                    
        extNum = numEntero % 10;
        numEntero /= 10;
        sumDigit += extNum;
    }
    if(sacarPrimo(sumDigit) == 1){
        printf("\nSu suma de los digitos de %d es primo: %f\n", n1, sumDigit);
    }
    return 0;
    }


void mostrarPrimos(){
    int num, nP3 = 0, numEntero;
    float extNum, sumDigit;
    printf("Ingrese el numero hasta donde quiere que se impriman primos: ");
    scanf("%d", &num);
    if(num < 1000){
        for(int i = 1; i < num+1; i++){
            if(sacarPrimo(i) == 1){
                printf("%d ", i);
                if(i > 99){
                    nP3++;
                }
                if(i > 9){
                    sumarSiPrimo(i);
                }
            }
        }
        printf("\nSe contaron %d numeros primos de 3 digitos", nP3);
    }
    return;
}

int main(){
    mostrarPrimos();
    return 0;
}