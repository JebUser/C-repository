#include <stdio.h>
//PROTOTIPOS
int sacarPrimo(int n);
int sumarSiPrimo(int n1);
int cantidadAsteriscos(int cant);
int contadoresNums(int cant);

//PUNTO 1 ==========================================================

int cantidadAsteriscos(int cant){ //Funcion que imprime los asteriscos
    int j = 0;
    while(j < 2){
        printf("%d ", cant);
        for(int i = 0; i < cant; i++){
            printf("* ");
        }
        printf("%d\n", cant);
        j++;
    }
    return 0;
}
void imprimirAsteriscos(){ //Procedimiento que hace que imprima los casos hasta un valor menor o igual 0
    int num, i;
    i = 0;
    do{
        printf("Ingrese cantidad de asteriscos: ");
        scanf("%d", &num);
        if(num < 16){
            if(num > 0){
                cantidadAsteriscos(num);
                i++;
            }
        }
        else{
            printf("Numero grande, ingrese otro\n");
        }
    }
    while(num > 0 && i < 10);
    return;
}

//=====================================
//PUNTO 2
int cont71 = 0;
void contador71(){ //Funcion para contar el 71
   
    if(cont71 == 0){
        printf("\nFelicitaciones\n");
        cont71++;
    }
    else if(cont71 == 1){
        printf("\nManana le doy un premio\n");
        cont71++;
    }
    else if(cont71 == 2){
        printf("\nEsta muy sospechoso\n");
        cont71++;
    }
    else{
        printf("\nSigue estando muy sospechoso\n");
    }
    return;
}

int contadoresNums(int cant){ // Funcion que cuenta los numeros
    int i = 0;
    int n = 0;
    int contador = 0;
    int contador5060 = 0;
    int acumulado = 0;
    float promedio = 0;
    do{
        printf("Ingrese numero entre 50 y 80: ");
        scanf("%d", &n);
        if(n > 49 && n <81){
            if(n == 71){
                contador71();
            }
            else if(n>49 && n<61){ //Cuenta # entre el 49 y 61
                contador5060++;
                contador++;
                acumulado+=n;
            }
            else{
                acumulado+=n;
                contador++;
            }
            i++;
        }
        else{
            printf("\nNumero no valido, ingrese otro\n");
        }
    }
    while(i < cant);
    promedio = acumulado/contador;
    printf("\nSe contaron %d numeros.\n", contador);
    printf("El promedio de los numeros es: %f\n", promedio);
    printf("Se contaron %d numeros entre el 50 y 60.\n", contador5060);
    return 0;
}
void juego(){
    int nums;
    printf("\nIngrese cantidad de numeros a ingresar: ");
    scanf("%d", &nums);
    contadoresNums(nums);
    return;
}

//================================
//PUNTO 3
int papa, tomate, cebolla, naranja, mango; //Producto por camion
int tPapa, tTomate, tCebolla, tNaranja, tMango; //Total de cada producto
int tB3, tB4;
void camionA(){ //Para preguntar por el camion A
    printf("Ingrese los kilos de papa: ");
    scanf("%d", &papa);
    return;
}
void camionB2(){ //Para preguntar sobre el camion B de 2 productos
    printf("Ingrese los kilos de papa: ");
    scanf("%d", &papa);
    printf("Ingrese los kilos de cebolla: ");
    scanf("%d", &cebolla);
    tCebolla+=cebolla;
    return;
}

void camionB3(){ //Para preguntar sobre el camion B de 3 productos
    printf("Ingrese los kilos de tomate: ");
    scanf("%d", &tomate);
    tTomate+=tomate;
    printf("Ingrese los kilos de cebolla: ");
    scanf("%d", &cebolla);
    tCebolla+=cebolla;
    printf("Ingrese los kilos de naranja: ");
    scanf("%d", &naranja);
    tNaranja+=naranja;
    return;
}

void camionB4(){ //Para preguntar sobre el camion B de 4 productos
    printf("Ingrese los kilos de tomate: ");
    scanf("%d", &tomate);
    printf("Ingrese los kilos de cebolla: ");
    scanf("%d", &cebolla);
    tCebolla+=cebolla;
    printf("Ingrese los kilos de naranja: ");
    scanf("%d", &naranja);
    tNaranja+=naranja;
    printf("Ingrese los kilos de mango: ");
    scanf("%d", &mango);
    tMango+=mango;
    return;
}

void seleccionB(){ //Para preguntar cuantos productos trae el camion B
    int prods;
    
    do{
        printf("Cuantos productos: ");
        scanf("%d", &prods);
        switch (prods){
        case 2:
            camionB2();
            break;
        case 3:
            camionB3();
            tB3++;
            break;
        case 4:
            camionB4();
            tB4++;
            break;
        default:
            printf("Numero no valido\n");
            break;
        }
    }
    while(prods < 2 || prods > 4);
    return;
}

void contarProds(){
    int camiones, tA, tB;
    
    do{
        printf("Cuantos camiones llegaron: ");
        scanf("%d", &camiones);
        printf("Cuantos de tipo A: ");
        scanf("%d", &tA);
        printf("Cuantos de tipo B: ");
        scanf("%d", &tB);
        if(tA+tB == camiones){
            if(tA > 0){
                printf("Camion A:\n");
                for(int i = 0; i < tA; i++){ //Abre el contador de camiones A y sus prods
                    camionA();
                }
            }
            if(tB > 0){
                printf("Camion B:\n");
                for(int j = 0; j < tB; j++){ // Abre el contador de camiones B y saber cuantos prods
                    seleccionB();
                }
            }
        }
        else {
            printf("Cantidad de camiones no valida\n");
        }
    }
    while(tA+tB != camiones);
    printf("\nResumen del trabajo:\n");
    printf("Llegaron %d camiones tipo A\n", tA);
    printf("Llegaron %d camiones de 3 productos y %d de 4 productos\n", tB3, tB4);
    printf("Llegaron %d kilos de cebolla\n", tCebolla);
    printf("Llegaron %d kilos de naranja\n", tNaranja);
    printf("Llegaron %d kilos de mango\n", tMango);
    return;
}

//=============================================================
//PUNTO 4
int sacarPrimo(int n){ //Funcion que mira si un numero es primo
    int esprimo = 1;
    for(int j = 2; j < n-1; j++){
        if(n%j == 0){
            esprimo = 0;
        }
    }
    if(esprimo == 1){
        return 1;
    }
    else{
        return 0;
    }
}

int sumarSiPrimo(int n1){ //Procedimiento que mira si la suma de los digitos de un numero es primo
    int num2 = n1;
    float sumaTotal = 0;
    float sumandoDigit = 0;
    while(num2 != 0){                    
        sumandoDigit = num2 % 10;
        num2 /= 10;
        sumaTotal += sumandoDigit;
    }
    if(sacarPrimo(sumaTotal) == 1){
        printf("La suma de los digitos de %d es primo: %f\n", n1, sumaTotal);
    }
    return 0;
    }


void mostrarPrimos(){
    int num, nP3 = 0, numEntero;
    float extNum, sumDigit;
    printf("Ingrese el numero hasta donde quiere que se impriman primos: ");
    scanf("%d", &num);
    if(num > 1000){
        for(int i = 100; i < num+1; i++){
            if(sacarPrimo(i) == 1){
                printf("%d ", i);
                if(i < 1000){
                    nP3++;
                }
            }
        }
        printf("\nSe contaron %d numeros primos de 3 digitos\n", nP3);
        for(int i = 2; i < num+1; i++){
            if(sacarPrimo(i) == 1){
                sumarSiPrimo(i);
            }
        }
    }
    else{
        printf("Numero no valido\n");
    }
    return;
}

//=======================================================
void menu(){
    int opcion;
    do{
        printf("\nBienvenido al taller 1\nQue ejercicio desea ejecutar\n");
        printf("1. ImprimirAsteriscos\n");
        printf("2. JuegoDigitarNumeros\n");
        printf("3. InventarioLaFarra\n");
        printf("4. PrimoshastaN\n");
        printf("5. Salir del programa\n");
        printf("Escoja: ");
        scanf("%d", &opcion);
        switch (opcion)
        {
        case 1:
            imprimirAsteriscos();
            break;
        case 2:
            juego();
            break;
        case 3:
            contarProds();
            break;
        case 4:
            mostrarPrimos();
            break;
        case 5:
            printf("Gracias por mirar el taller\nTerminando...");
            break;
        default:
            printf("Opcion no valida, esocoja otra.\n");
            break;
        }
    }
    while(opcion != 5);
    return;
}

int main(){
    menu();
    return 0;
}