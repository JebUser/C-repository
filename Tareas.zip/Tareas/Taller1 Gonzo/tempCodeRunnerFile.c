
        scanf("%d", &tA);