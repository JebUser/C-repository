#include<stdlib.h>
#include<stdio.h>

//Structs

typedef struct carro{
    int placa;
    char color[15];
    char nombre[30];
}Carro;

typedef struct nodo{
	Carro carroP;
	struct nodo * pSgte;
}nodo;

typedef struct pila{
    nodo *pCabezaPila;
}pilaP;

typedef enum{
	VACIA = 0,
	NO_VACIA = 1,
    EXISTE = 1,
    NO_EXISTE = 0
}estado;

//Prototipos

pilaP crearPila(void);
estado esPilaVacia(pilaP *pPila);
Carro agregarCarro(void);
int existePlaca(pilaP pPila, int placaVer);
void sacarCarro(pilaP *pPila, int placaSacar);
void reacomodarInicio(pilaP *pPila, int placaSacar);
void pushPila(pilaP *pPila, Carro nuevoCarro);
void popPila(pilaP *pPila);
void imprimirPila(pilaP pPila);
void Menu(pilaP pPila);

//Funciones

pilaP crearPila(void){
	pilaP nuevapPila;
	nuevapPila.pCabezaPila = NULL;
	return nuevapPila;
}

estado esPilaVacia(pilaP *pPila){
	if(pPila->pCabezaPila == NULL){
		return VACIA;
	}else{
		return NO_VACIA;
	}
}

Carro agregarCarro(void){
    Carro nuevoCarro;
    printf("Ingrese placa del carro:\n");
    scanf("%d", &nuevoCarro.placa);
    printf("Ingrese color del carro(Use menos de 15 caracteres):\n");
    fflush(stdin);
    fgets(nuevoCarro.color, 15, stdin);
    printf("Ingrese nombre del propietario(use menos de 30 caracteres, espacios cuentan):\n");
    fflush(stdin);
    fgets(nuevoCarro.nombre, 30, stdin);
    return nuevoCarro;
}

int existePlaca(pilaP pPila, int placaVer){
    pilaP pilaRepuesto = crearPila();
    Carro datAux;
    int existe = NO_EXISTE;
    while(pPila.pCabezaPila != NULL){ //Pasa de la pila original a la de repuesto
        if(pPila.pCabezaPila->carroP.placa == placaVer){
            existe = EXISTE;
        }
        datAux = pPila.pCabezaPila->carroP;
        popPila(&pPila);
        pushPila(&pilaRepuesto, datAux);
    }
    while(pilaRepuesto.pCabezaPila != NULL){ //Lo mismo de arriba pero a la inversa
        datAux = pilaRepuesto.pCabezaPila->carroP;
        popPila(&pilaRepuesto);
        pushPila(&pPila, datAux);
    }    
    return existe;
}

void sacarCarro(pilaP *pPila, int placaSacar){
    if(pPila->pCabezaPila->pSgte == NULL){
        if(pPila->pCabezaPila->carroP.placa == placaSacar){
            printf("Se saco el carro de placa %d\n", pPila->pCabezaPila->carroP.placa);
            popPila(pPila);
        }
        else{
            printf("Placa no valida\n");
        }
    }
    else{    
        pilaP pilaRepuesto = crearPila();
        Carro datAux;
        datAux = pPila->pCabezaPila->carroP;
        while(pPila->pCabezaPila != NULL){ //Pasa de la pila original a la de repuesto
            if(pPila->pCabezaPila->carroP.placa == placaSacar){
                printf("Se saco el carro de placa %d\n", pPila->pCabezaPila->carroP.placa);
                popPila(pPila);
            }
            else{
                datAux = pPila->pCabezaPila->carroP;
                popPila(pPila);
                pushPila(&pilaRepuesto, datAux);
            }

        }
        while(pilaRepuesto.pCabezaPila != NULL){ //Lo mismo de arriba pero a la inversa
            datAux = pilaRepuesto.pCabezaPila->carroP;
            popPila(&pilaRepuesto);
            pushPila(pPila, datAux);
        } 
    }
}

void reacomodarInicio(pilaP *pPila, int placaSacar){
    pilaP pilaRepuesto = crearPila();
    Carro datAux;
    Carro datInicio;
    datAux = pPila->pCabezaPila->carroP;
    while(pPila->pCabezaPila != NULL){ //Pasa de la pila original a la de repuesto
        if(pPila->pCabezaPila->carroP.placa == placaSacar){
            datInicio = pPila->pCabezaPila->carroP;
            popPila(pPila);
        }
        else{
            datAux = pPila->pCabezaPila->carroP;
            popPila(pPila);
            pushPila(&pilaRepuesto, datAux);
        }

    }
    while(pilaRepuesto.pCabezaPila != NULL){ //Lo mismo de arriba pero a la inversa
        datAux = pilaRepuesto.pCabezaPila->carroP;
        popPila(&pilaRepuesto);
        pushPila(pPila, datAux);
    }
    pushPila(pPila, datInicio);
}

void pushPila(pilaP *pPila, Carro nuevoCarro){
	nodo *nuevoNodo = (nodo*)malloc(sizeof(nodo));
	if (nuevoNodo == NULL){
		printf("No hubo memoria suficiente para crear el nodo\n");
	}else{
		nuevoNodo->carroP = nuevoCarro;
		if(esPilaVacia(pPila) == VACIA){
			nuevoNodo->pSgte = NULL;
		}else{
			nuevoNodo->pSgte = pPila->pCabezaPila;		
		}
		pPila->pCabezaPila = nuevoNodo;
        
	}
}

void popPila(pilaP *pPila){
    if(esPilaVacia(pPila) == NO_VACIA){
        nodo *pAuxCabeza = pPila->pCabezaPila;
        nodo *pAuxSgte = pPila->pCabezaPila->pSgte;
        free(pAuxCabeza);
        pPila->pCabezaPila = pAuxSgte;
    }
    else{
        printf("Parqueadero vacio, no se pueden sacar carros\n");
    }
}

void imprimirPila(pilaP pPila){
    pilaP pilaRepuesto = crearPila();
    Carro datAux;
    while(pPila.pCabezaPila != NULL){ //Pasa de la pila original a la de repuesto
        printf("===============================================================\n");
        printf("Propietario del vehiculo: %s", pPila.pCabezaPila->carroP.nombre);
        printf("Placa del vehiculo: %d\n", pPila.pCabezaPila->carroP.placa);
        datAux = pPila.pCabezaPila->carroP;
        popPila(&pPila);
        pushPila(&pilaRepuesto, datAux);
    }
    printf("===============================================================\n");
    while(pilaRepuesto.pCabezaPila != NULL){ //Lo mismo de arriba pero a la inversa
        datAux = pilaRepuesto.pCabezaPila->carroP;
        popPila(&pilaRepuesto);
        pushPila(&pPila, datAux);
    }
}


void Menu(pilaP pPila){
    int sel, placa;
    Carro nCarro;
    do{
        printf("Que accion quiere realizar?\n");
        printf("1. Agregar Coche\n2. Salir\n3. Imprimir Parqueadero\n4. Sacar Carro\n5. Sacar carro 10 min antes\n6. Buscar Carro\n");
        scanf("%d", &sel);
        switch (sel)
        {
        case 1:
            nCarro = agregarCarro();
            pushPila(&pPila, nCarro);
            break;
        case 2:
            printf("Saliendo\n");
            break;
        case 3:
        if(esPilaVacia(&pPila) == NO_VACIA){
            imprimirPila(pPila);
        }
        else{
            printf("Parqueadero vacio\n");
        }
            break;
        case 4:
        if(esPilaVacia(&pPila) == NO_VACIA){
            printf("Ingrese placa del vehiculo a retirar:\n");
            scanf("%d", &placa);
            sacarCarro(&pPila, placa);
        }
        else{
            printf("Parqueadero vacio\n");
        }
        break;

        case 5:
        if(esPilaVacia(&pPila) == NO_VACIA){
            printf("Ingrese placa del vehiculo a retirar:\n");
            scanf("%d", &placa);
            if(pPila.pCabezaPila->carroP.placa == placa){
                popPila(&pPila);
            }
            else{
                reacomodarInicio(&pPila, placa);
                imprimirPila(pPila);
                popPila(&pPila);
            }
        }
        else{
            printf("Parqueadero vacio\n");
        }
        break;
        case 6:
        if(esPilaVacia(&pPila) == NO_VACIA){
            printf("Ingrese placa del vehiculo a retirar:\n");
            scanf("%d", &placa);
            if(existePlaca(pPila, placa) == EXISTE){
                printf("El carro esta en el parqueadero\n");
            }
            else{
                printf("El carro no existe en el parqueadero\n");
            }
        }
        else{
            printf("Parqueadero vacio\n");
        }
        break;
        default:
            printf("Numero no valido\n");
            break;
        }
    }
    while(sel != 2);
}

int main(){
    pilaP parqueadero = crearPila();
    Menu(parqueadero);
    return 0;
}